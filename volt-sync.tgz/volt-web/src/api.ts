// Typed client for the Volt control-plane API (same-origin via the Vite proxy).
let token = ''
export function setToken(t: string) { token = t }
export function getToken() { return token }

/**
 * An API failure that still knows what KIND of failure it was.
 *
 * Every caller used to receive `new Error(String(status))`, so no page could
 * tell "your session expired" from "you are not allowed to do that" from "the
 * server broke" — and every page rendered whichever it got as a bare number.
 * Now the status travels with the message and pages can react to it.
 */
export class ApiError extends Error {
  // Declared and assigned, not written as a constructor parameter property:
  // the build runs with `erasableSyntaxOnly`, which rejects the shorthand
  // because it is TypeScript that EMITS code rather than TypeScript that is
  // merely erased.
  status: number
  constructor(status: number, message: string) {
    super(message)
    this.status = status
    this.name = 'ApiError'
  }
  /** The session is gone. Nothing the page can do about it. */
  get unauthorized() { return this.status === 401 }
  /** Authenticated, but this is not yours to see or do. */
  get forbidden() { return this.status === 403 }
}

/**
 * Called when the API says the session is over. App.tsx registers a handler
 * that returns the user to the sign-in screen; without one, an expired token
 * left every page showing the string "401" and the live status stream
 * reconnecting every three seconds with the same dead credential, forever.
 */
let onUnauthorized: (() => void) | null = null
export function setUnauthorizedHandler(fn: (() => void) | null) { onUnauthorized = fn }

async function req(path: string, opts: RequestInit = {}) {
  const r = await fetch('/api' + path, {
    ...opts,
    headers: {
      'content-type': 'application/json',
      ...(token ? { authorization: `Bearer ${token}` } : {}),
      ...(opts.headers || {}),
    },
  })
  if (!r.ok) {
    let msg = `${r.status}`
    try { msg = (await r.json()).error || msg } catch { try { msg = await r.text() } catch { /* no body */ } }
    if (r.status === 401 && token) { token = ''; onUnauthorized?.() }
    throw new ApiError(r.status, msg)
  }
  if (r.status === 204) return null
  return r.json()
}

export interface Group {
  id: string; name: string; profile_name: string | null
  workflow_type: 'transcode' | 'package_only' | null
  packaging: string | null; rungs: { height: number; bitrate_kbps: number }[] | null
  codec_backend: string | null; captions_provider: 'none' | 'whisper' | 'gladia'
  max_channels: number; channel_count: number
}
export interface Channel {
  id: string; name: string; status: string; group_id: string
  enabled?: boolean; recording_enabled?: boolean
  recording_retention_days: number | null; recording_retention_sec?: number | null
  created_at: string; version: number; group_name?: string
  dvr_window_sec: number | null; dvr_mode: 'sliding' | 'event_start'
  geo_mode: 'worldwide' | 'allow' | 'block'; geo_countries: string[]
  input_loss_behavior?: 'none' | 'slate' | 'vod_loop' | 'last_frame' | 'black'
  input_failover_enabled?: boolean
  auto_failback?: boolean
  filler_slate_ref?: string | null
  pipelineState?: 'idle' | 'starting' | 'ready' | 'onair' | 'degraded' | 'error' | 'stopped'
  billable?: boolean
  serverSince?: number | null
  on_air?: boolean
  brand_ref?: string | null
}

export interface SearchHit { kind: 'channel' | 'event' | 'recording'; id: string; name: string; href: string; sub?: string }

export interface Billing {
  billable: boolean
  since: number | null
  elapsedSec: number
  instance: string
  rateUsdPerHour: number
  estRunUsd: number
  indicative: true
  basis: string
}

export interface ChannelDetail extends Channel {
  kind: 'channel'
  group: { id: string; name: string } | null
  profile: {
    name: string; workflow_type: 'transcode' | 'package_only'; packaging: string
    rungs: { height: number; bitrate_kbps: number }[]; segment_dur: number
    dvr_window_sec: number
  } | null
  dvr: { effective_sec: number; max_sec: number; mode: string; source: 'channel' | 'profile'; capped: boolean }
  captions: { enabled: boolean; targets: string[]; source_lang: string; offset_sec?: number }
  epgEnabled: boolean
  ladder: { height: number; bitrate_kbps: number }[]
  sources: { id: string; role: string; protocol: string; ingest_url: string | null; status: string }[]
  viewers: { current: number; peak: number; peakAt: string; trendPct: number; series: { t: number; v: number }[] }
  epg: { now: any; next: { name: string; start: string } | null; lane: any[] }
  statusBoard: { output: string; activeSource: string; fallback: string; packager: string; inputs: any[] }
  log: { ts: string; level: string; title: string; detail: string }[]
  health: PipelineHealth
  billing: Billing
  testStream: TestStreamStatus
  onAir: boolean
  public: { url: string; dashUrl: string; available: boolean }
  watermark: WatermarkCfg
}

export interface WatermarkCfg {
  enabled: boolean
  ref: string | null
  position: 'tl' | 'tr' | 'bl' | 'br' | 'tc' | 'bc'
  offsetX: number
  offsetY: number
  opacity: number
  scale: number
}
export interface WatermarkPatch {
  enabled?: boolean; ref?: string | null
  position?: 'tl' | 'tr' | 'bl' | 'br' | 'tc' | 'bc'
  offsetX?: number; offsetY?: number; opacity?: number; scale?: number
}

export type GateStatus = 'idle' | 'starting' | 'ready' | 'healthy' | 'degraded' | 'failed' | 'stopped'
export interface Gate {
  gate: 'server' | 'input' | 'encoder' | 'output' | 'public'
  label: string
  status: GateStatus
  detail: string
  billable: boolean
}
export interface PipelineHealth {
  gates: Gate[]
  primaryError: { gate: string; label: string; message: string } | null
  onAir: boolean
  live: boolean
  overall: 'idle' | 'starting' | 'ready' | 'onair' | 'degraded' | 'error' | 'stopped'
}

export interface TestStreamStatus {
  available: boolean
  running: boolean
  producer?: 'test' | 'encoder' | null
  startedAt: number | null
  hls: string
  dash: string | null
  subtitles: Record<string, string>
  poster?: string | null
  thumbsVtt?: string | null
  options: { name: string; dvrSec: number; langs: string[]; dash: boolean; captionInterval: number } | null
  sourceKind: 'ingest' | 'testcard' | null
  sourceUrl: string | null
  sourceNote: string | null
}

export interface ChannelSettingsPatch {
  name?: string
  recordingEnabled?: boolean
  recordingRetentionDays?: number | null
  /** Retention in SECONDS, which is what the settings form actually sends: the
   *  UI offers minutes, hours and days and converts. The API has accepted this
   *  since retention became sub-day; the client type had not caught up, so every
   *  save was an untyped property that happened to work. */
  recordingRetentionSec?: number | null
  /** Transcode rungs. Same story: sent, accepted, undeclared. */
  outputLadder?: { height: number; bitrateKbps: number }[] | null
  dvrWindowSec?: number | null
  dvrMode?: 'sliding' | 'event_start'
  geoMode?: 'worldwide' | 'allow' | 'block'
  geoCountries?: string[]
  epgEnabled?: boolean
  sources?: { role: 'primary' | 'backup'; protocol: string; ingestUrl?: string; streamKey?: string }[]
  captions?: { enabled?: boolean; sourceLang?: string; targets?: string[]; offsetSec?: number }
  inputFailoverEnabled?: boolean
  autoFailback?: boolean
  inputLossBehavior?: 'none' | 'slate' | 'vod_loop' | 'last_frame' | 'black'
  fillerSlateRef?: string | null
  watermark?: WatermarkPatch
  brandRef?: string | null
  radio?: RadioCfg
  version?: number
}

export type FailoverMode = 'auto' | 'primary_down' | 'backup' | 'slate' | 'loop'
export interface FailoverTestState {
  mode: FailoverMode
  realFailover: boolean
  workflowType: 'transcode' | 'package_only' | null
  autoFailback: boolean | null
  lossBehavior: string | null
  loopKind: 'uploaded' | 'motion_slate' | 'slate' | null  // what the loop filler will be
  hasSlate: boolean
  hasBackup: boolean
}


/** What a recording source IS (never `recordings.kind`, which is how the capture
 *  is sliced: a radio station's captures are 'channel_day' too). */
export type RecordingSourceType = 'channel' | 'radio' | 'event'
export interface RecordingSource {
  id: string
  name: string
  type: RecordingSourceType
  brandRef: string | null
  createdAt: string
  recordings: number
  firstStartMs: number | null
  lastEndMs: number | null
  lastStartMs: number | null
  totalDurationMs: number
  /** Truthful: something is capturing RIGHT NOW, asked of the pipeline. */
  capturing: boolean
  state: 'recording' | 'idle' | 'off'
  retentionDays: number | null
  nextExpiry: string | null
}
export interface RecordingSourcesFeed {
  sources: RecordingSource[]
  counts: { all: number; channel: number; radio: number; event: number; capturing: number }
}
export interface RecordingSourceQuery {
  type?: string; q?: string
  sort?: 'name' | 'recorded' | 'created' | 'count' | 'duration'
  dir?: 'asc' | 'desc'
  recordedFrom?: number; recordedTo?: number
  createdFrom?: number; createdTo?: number
  recordingNow?: '1' | '0'
}


/** What a source URL says about itself, read before anything is saved. */
export interface IcyProbe {
  ok: boolean
  url: string
  resolved: boolean
  error: string | null
  station: { name?: string; genre?: string; url?: string; bitrateKbps?: number; contentType?: string; description?: string; public?: boolean }
  nowPlaying: string | null
  streamUrl: string | null
  artworkUrl: string | null
  hasMetadata: boolean
  metaIntervalBytes: number | null
}


// ---- timeline, coverage and dayparts ---------------------------------------
export interface TimelineRun { runId: string; startMs: number; endMs: number; segments: number }
export interface TimelineGap { fromMs: number; toMs: number; ms: number; reason: string }
export interface BroadcastDayRow {
  day: string; startMs: number; endMs: number; hours: number
  /** 'forward' on a 23-hour day, 'back' on a 25-hour day, else null. */
  clockChange: 'forward' | 'back' | null
}
export interface ContainerRow {
  id: string; day: string; startMs: number; endMs: number
  recordings: number; recordedMs: number; coveragePct: number; state: 'open' | 'closed'
}
export interface DaypartStrip { name: string; startMs: number; endMs: number }
export interface TimelineProgramme {
  id: string; title: string; startMs: number; endMs: number
  asRun: boolean; status: string; class: string | null; source: string
}
export interface TimelineFeed {
  channelId: string; name: string
  window: { from: number; to: number; ms: number }
  clock: { tz: string; anchorHour: number; presetId: string | null }
  kind: 'video' | 'audio'
  media: { coveragePct: number; runs: TimelineRun[]; gaps: TimelineGap[] }
  days: BroadcastDayRow[]
  containers: ContainerRow[]
  dayparts: DaypartStrip[]
  programmes: TimelineProgramme[]
}
export interface CoverageFeed {
  channelId: string
  window: { from: number; to: number; ms: number }
  coveragePct: number; coveredMs: number
  effectiveFromMs: number | null; effectiveToMs: number | null
  runs: (TimelineRun & { rendition: string })[]
  gaps: TimelineGap[]
  segments: number
  clippable: boolean
  reason: { code: string; message: string } | null
  strategy: 'full-render' | 'copy'
}
export interface DaypartDef { name: string; startsLocal: string; daysMask?: number }
export interface DaypartPreset {
  id: string; label: string; market: string; appliesTo: string; dayparts: DaypartDef[]
}
export interface JobRow {
  id: string; type: string; state: 'queued' | 'running' | 'succeeded' | 'failed' | 'cancelled'
  progress_pct: number; progress_note: string | null
  attempts: number; max_attempts: number
  last_error: string | null; error_code: string | null
  result?: any
  created_at: string; started_at: string | null; finished_at: string | null
  source_name?: string | null
}


export interface WaveBucket { t: number; peak: number; rms: number }
export interface ChannelWaveform {
  channelId: string
  from: number; to: number; bucketMs: number
  mode: 'exact' | 'sampled'
  complete: boolean; pending: number; priming: boolean
  buckets: (WaveBucket | null)[]
}

/* ---- fleet: servers and billable usage ---------------------------------- */

/** A reading that could not be taken is null, NEVER zero. The UI must show
 *  "no reading" rather than drawing an idle machine that is actually
 *  unreachable, which is the one wrong answer an operator would act on. */
export interface HostMetrics {
  at: string
  source: 'cloudwatch' | 'onbox' | 'task_stats'
  cpuPct: number | null
  memPct: number | null
  netInBps: number | null
  netOutBps: number | null
  tasksAtSample: number | null
}

export interface HostStream {
  instanceId: string
  id: string
  type: 'channel' | 'radio' | 'event'
  name: string | null
  taskKind: string | null
  role: string
  launchedAt: string | null
}

export interface FleetHost {
  id: string
  kind: 'ec2' | 'fargate' | 'local'
  externalId: string
  instanceType: string | null
  availabilityZone: string | null
  region: string | null
  lifecycle: 'spot' | 'on_demand' | null
  vcpus: number | null
  memoryMib: number | null
  firstSeenAt: string
  lastSeenAt: string
  /** The MACHINE's load, which is what capacity questions need. */
  tasksTotal: number
  streamsTotal: number
  /** This tenant's share of it. */
  tasksYours: number
  streamsYours: number
  taskKinds: string[]
  metrics: HostMetrics | null
  streams: HostStream[]
}

export interface UsageBucket {
  periodStart: string
  seconds: number
  serversUsed: number
  taskRuns: number
  streams: number
  byTaskKind: Record<string, number>
}

export interface StreamUsage {
  id: string
  kind: 'channel' | 'event'
  name: string | null
  channelKind: string | null
  allTimeSeconds: number
  todaySeconds: number
  monthSeconds: number
  /** Running but not yet settled by the meter. Shown apart from the rest. */
  pendingSeconds: number
  runs: number
  lastUsedAt: string | null
}

export interface UsageTotals {
  todaySeconds: number
  monthSeconds: number
  allTimeSeconds: number
  pendingSeconds: number
  serversToday: number
  serversMonth: number
  streamsToday: number
}

export interface FleetUsage {
  period: 'day' | 'week' | 'month' | 'year'
  generatedAt: string
  totals: UsageTotals
  series: UsageBucket[]
  streams: StreamUsage[]
  unit: 'seconds'
}

export const api = {
  login: (email: string, password: string) =>
    req('/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) }),
  groups: (): Promise<Group[]> => req('/groups'),
  // caption OUTPUT languages the pipeline can deliver (single source of truth for pickers)
  captionLanguages: (): Promise<{ languages: { code: string; label: string }[] }> => req('/caption-languages'),
  channels: (kind?: 'tv' | 'radio'): Promise<Channel[]> => req('/channels' + (kind ? `?kind=${kind}` : '')),
  createChannel: (b: {
    groupId: string; name: string; purchasingMode?: string
    resilienceTier?: string; recordingEnabled?: boolean
    recordingRetentionDays?: number | null; recordingRetentionSec?: number | null
    dvrWindowSec?: number | null; dvrMode?: 'sliding' | 'event_start'
    outputLadder?: { height: number; bitrateKbps: number }[]
    sources?: { role: 'primary' | 'backup'; protocol: string; ingestUrl?: string; streamKey?: string; renditionLabel?: string; renditionBitrateKbps?: number }[]
    inputFailoverEnabled?: boolean; autoFailback?: boolean
    inputLossBehavior?: 'none' | 'slate' | 'vod_loop' | 'last_frame' | 'black'
    fillerSlateRef?: string | null; fillerAssetId?: string | null
    fallbackTranscode?: boolean
    watermark?: WatermarkPatch
    brandRef?: string | null
    kind?: 'tv' | 'radio'
    radio?: RadioCfg
  }): Promise<Channel> => req('/channels', { method: 'POST', body: JSON.stringify(b) }),
  search: (q: string): Promise<{ results: SearchHit[] }> => req('/search?q=' + encodeURIComponent(q)),
  startStop: (id: string, action: 'start' | 'stop') =>
    req(`/channels/${id}/${action}`, { method: 'POST' }),
  // Go on air / take off air — the PUBLIC publish toggle (opens/closes /live/:id/...).
  setAir: (id: string, on: boolean): Promise<Channel> =>
    req(`/channels/${id}/air`, { method: 'POST', body: JSON.stringify({ on }) }),
  // Pre-on-air failover test: force the encoder to slate/loop/backup (or simulate a
  // primary loss), then resume with mode 'auto'. `realFailover` is true only when the
  // encoder selector is actually running (redundancy-enabled package channel).
  failoverTest: (id: string, mode: FailoverMode): Promise<FailoverTestState> =>
    req(`/channels/${id}/failover-test`, { method: 'POST', body: JSON.stringify({ mode }) }),
  failoverTestStatus: (id: string): Promise<FailoverTestState> =>
    req(`/channels/${id}/failover-test`),
  // Share link — a private, PIN/expiry-secured preview of THIS channel's output, for
  // clients/reviewers to approve before go-live. Not on air, ignores geo/access rules.
  createShareLink: (b: {
    resourceKind: 'vod' | 'channel' | 'event'; resourceId: string
    accessPeriod?: string; ttlSec?: number; label?: string; message?: string
    pin?: string; maxViews?: number | null
    recipients?: string[]
    authMode?: 'none' | 'pin' | 'email_pin'
    sendEmail?: boolean
  }): Promise<{ id: string; url: string; token: string; expiresAt: string; emailed: number }> =>
    req('/share-links', { method: 'POST', body: JSON.stringify(b) }),
  shareLinks: (): Promise<ShareLinkRow[]> => req('/share-links'),
  revokeShareLink: (id: string): Promise<{ id: string; revoked: boolean }> =>
    req(`/share-links/${id}/revoke`, { method: 'POST' }),
  channel: (id: string): Promise<ChannelDetail> => req(`/channels/${id}`),
  updateChannel: (id: string, patch: ChannelSettingsPatch): Promise<any> =>
    req(`/channels/${id}`, { method: 'PATCH', body: JSON.stringify(patch) }),
  testStreamStart: (id: string, opts: { langs?: string[]; dvrSec?: number; dash?: boolean } = {}): Promise<TestStreamStatus> =>
    req(`/channels/${id}/test-stream`, { method: 'POST', body: JSON.stringify({ action: 'start', ...opts }) }),
  testStreamStop: (id: string): Promise<{ running: boolean }> =>
    req(`/channels/${id}/test-stream`, { method: 'POST', body: JSON.stringify({ action: 'stop' }) }),
  ingestProtocols: (): Promise<{ protocols: IngestProtocol[] }> => req('/ingest-protocols'),

  // image library (file manager)
  files: (p: { folder?: string; kind?: string; q?: string; recursive?: boolean } = {}): Promise<MediaFile[]> => {
    const qs = new URLSearchParams()
    if (p.folder !== undefined) qs.set('folder', p.folder)
    if (p.kind) qs.set('kind', p.kind)
    if (p.q) qs.set('q', p.q)
    if (p.recursive) qs.set('recursive', '1')
    return req('/files' + (qs.toString() ? '?' + qs : ''))
  },
  // events — same core workflow as channels plus the scheduled window
  events: (): Promise<EventRow[]> => req('/events'),
  event: (id: string): Promise<EventRow> => req(`/events/${id}`),
  createEvent: (b: EventCreateBody): Promise<EventRow> =>
    req('/events', { method: 'POST', body: JSON.stringify(b) }),
  updateEvent: (id: string, patch: EventPatchBody): Promise<EventRow> =>
    req(`/events/${id}`, { method: 'PATCH', body: JSON.stringify(patch) }),
  eventStartStop: (id: string, action: 'start' | 'stop'): Promise<EventRow> =>
    req(`/events/${id}/${action}`, { method: 'POST' }),
  deleteEvent: async (id: string): Promise<void> => {
    const r = await fetch('/api/events/' + id, { method: 'DELETE', headers: { authorization: `Bearer ${getToken()}` } })
    if (!r.ok && r.status !== 204) throw new Error(String(r.status))
  },

  // EPG — programme guides for channels and event-day schedules
  epgOwners: (): Promise<EpgOwnerRow[]> => req('/epg/owners'),
  epgProgrammes: (owner: EpgOwner, fromIso: string, toIso: string): Promise<ProgrammeRow[]> =>
    req(`/epg?${owner.kind === 'event' ? 'eventId' : 'channelId'}=${owner.id}&from=${encodeURIComponent(fromIso)}&to=${encodeURIComponent(toIso)}`),
  /** The VoD lifecycle for a window, keyed by programme id. Measured against
   *  the archive on disk, so it is a separate read from the listing itself. */
  epgVodStatus: (owner: EpgOwner, fromIso: string, toIso: string): Promise<{ programmes: Record<string, ProgrammeVod> }> =>
    req(`/epg/vod-status?ownerKind=${owner.kind}&ownerId=${owner.id}&from=${encodeURIComponent(fromIso)}&to=${encodeURIComponent(toIso)}`),
  /** Convert an aired slot to a VOD now. Runs the same conversion the
   *  scheduler runs; 409 if it is already converted or in flight. */
  convertProgramme: (id: string): Promise<{ assetId: string }> =>
    req(`/epg/${encodeURIComponent(id)}/convert`, { method: 'POST' }),
  epgConflicts: (owner: EpgOwner, fromIso: string, toIso: string): Promise<ProgrammeConflict[]> =>
    req(`/epg/conflicts?${owner.kind === 'event' ? 'eventId' : 'channelId'}=${owner.id}&from=${encodeURIComponent(fromIso)}&to=${encodeURIComponent(toIso)}`),
  createProgramme: (owner: EpgOwner, b: ProgrammeBody): Promise<ProgrammeRow & { conflicts: { id: string; title: string }[] }> =>
    req('/epg', { method: 'POST', body: JSON.stringify({ ...(owner.kind === 'event' ? { eventId: owner.id } : { channelId: owner.id }), ...b }) }),
  patchProgramme: (id: string, b: Partial<ProgrammeBody>): Promise<ProgrammeRow> =>
    req(`/epg/${id}`, { method: 'PATCH', body: JSON.stringify(b) }),
  deleteProgramme: async (id: string): Promise<void> => {
    const r = await fetch('/api/epg/' + id, { method: 'DELETE', headers: { authorization: `Bearer ${getToken()}` } })
    if (!r.ok && r.status !== 204) throw new Error(String(r.status))
  },
  epgCopyDay: (owner: EpgOwner, fromStart: string, fromEnd: string, dayOffsets: number[]): Promise<{ copied: number; created: number }> =>
    req('/epg/copy-day', { method: 'POST', body: JSON.stringify({ ...(owner.kind === 'event' ? { eventId: owner.id } : { channelId: owner.id }), fromStart, fromEnd, dayOffsets }) }),
  epgClearDay: (owner: EpgOwner, fromStart: string, fromEnd: string): Promise<{ deleted: number }> =>
    req('/epg/clear-day', { method: 'POST', body: JSON.stringify({ ...(owner.kind === 'event' ? { eventId: owner.id } : { channelId: owner.id }), fromStart, fromEnd }) }),

  // recordings library + range playback + clip/VOD creation
  /** Sources roll-up: one row per channel / radio station / event that has
   *  recordings. Sorting and filtering are server-side because the counts and
   *  the available range are computed in SQL. */
  /** Ask a source URL what it is, before saving it. Nothing is written. */
  probeRadioSource: (url: string): Promise<IcyProbe> =>
    req('/radio/probe', { method: 'POST', body: JSON.stringify({ url }) }),
  /** The three lanes in one call, so they cannot disagree about a boundary. */
  channelTimeline: (id: string, from: number, to: number): Promise<TimelineFeed> =>
    req(`/channels/${id}/timeline?from=${Math.round(from)}&to=${Math.round(to)}`),
  /** The waveform for a window, at the caller's pixel resolution. */
  channelWaveform: (id: string, from: number, to: number, buckets: number, prime = true): Promise<ChannelWaveform> =>
    req(`/channels/${id}/waveform?from=${Math.round(from)}&to=${Math.round(to)}&buckets=${Math.round(buckets)}${prime ? '&prime=1' : ''}`),
  channelCoverage: (id: string, from: number, to: number): Promise<CoverageFeed> =>
    req(`/channels/${id}/coverage?from=${Math.round(from)}&to=${Math.round(to)}`),
  channelDayparts: (id: string): Promise<{ presetId: string | null; tz: string; anchorHour: number; dayparts: DaypartDef[] }> =>
    req(`/channels/${id}/dayparts`),
  setChannelDayparts: (id: string, body: { presetId?: string; dayparts?: DaypartDef[]; tz?: string; anchorHour?: number }) =>
    req(`/channels/${id}/dayparts`, { method: 'PUT', body: JSON.stringify(body) }),
  daypartPresets: (): Promise<{ presets: DaypartPreset[] }> => req('/daypart-presets'),
  job: (id: string): Promise<JobRow & { attempts: any[] }> => req(`/jobs/${id}`),
  jobs: (p: { type?: string; state?: string; channelId?: string } = {}): Promise<{ jobs: JobRow[] }> => {
    const qs = new URLSearchParams()
    for (const [k, v] of Object.entries(p)) if (v) qs.set(k, String(v))
    return req('/jobs' + (qs.toString() ? '?' + qs : ''))
  },
  retryJob: (id: string) => req(`/jobs/${id}/retry`, { method: 'POST' }),
  cancelJob: (id: string) => req(`/jobs/${id}/cancel`, { method: 'POST' }),
  recordingSources: (p: RecordingSourceQuery = {}): Promise<RecordingSourcesFeed> => {
    const qs = new URLSearchParams()
    for (const [k, v] of Object.entries(p)) if (v != null && v !== '') qs.set(k, String(v))
    return req('/recordings/sources' + (qs.toString() ? '?' + qs : ''))
  },
  recordings: (p: { kind?: string; channelId?: string; sourceId?: string; q?: string } = {}): Promise<RecordingRow[]> => {
    const qs = new URLSearchParams()
    if (p.kind) qs.set('kind', p.kind)
    if (p.channelId) qs.set('channelId', p.channelId)
    if (p.sourceId) qs.set('sourceId', p.sourceId)
    if (p.q) qs.set('q', p.q)
    return req('/recordings' + (qs.toString() ? '?' + qs : ''))
  },
  // transcript probe/search: no q = languages + entry count (add from/to for the
  // cues in that window); with q = timed matches across the whole recording
  recordingTranscript: (id: string, p: { q?: string; lang?: string; from?: number; to?: number } = {}): Promise<TranscriptSearch> => {
    const qs = new URLSearchParams()
    if (p.q) qs.set('q', p.q)
    if (p.lang) qs.set('lang', p.lang)
    if (p.from != null) qs.set('from', String(Math.round(p.from)))
    if (p.to != null) qs.set('to', String(Math.round(p.to)))
    return req(`/recordings/${id}/transcript` + (qs.toString() ? '?' + qs : ''))
  },
  recordingProgrammes: (id: string, p: { from?: number; to?: number; limit?: number } = {}): Promise<{ window?: { from: number; to: number }; programmes: RecordingProgramme[] }> => {
    const qs = new URLSearchParams()
    if (p.from != null) qs.set('from', String(Math.round(p.from)))
    if (p.to != null) qs.set('to', String(Math.round(p.to)))
    if (p.limit) qs.set('limit', String(p.limit))
    return req(`/recordings/${id}/programmes` + (qs.toString() ? '?' + qs : ''))
  },
  /** Audio envelope for the clipping timeline over [from..to] in `buckets` columns. */
  recordingWaveform: (id: string, from: number, to: number, buckets: number): Promise<Waveform> =>
    req(`/recordings/${id}/waveform?from=${Math.round(from)}&to=${Math.round(to)}&buckets=${Math.round(buckets)}`),
  recording: (id: string): Promise<RecordingRow & { vod_assets: VodAssetRow[] }> => req(`/recordings/${id}`),
  recordingTimeline: (id: string): Promise<RecordingTimeline> => req(`/recordings/${id}/timeline`),
  clipRecording: (id: string, b: { title: string; startMs: number; endMs: number; outputKind?: 'manifest' | 'progressive' | 'both' }): Promise<VodAssetRow> =>
    req(`/recordings/${id}/clip`, { method: 'POST', body: JSON.stringify(b) }),
  publishRecording: (id: string, title?: string): Promise<VodAssetRow> =>
    req(`/recordings/${id}/publish`, { method: 'POST', body: JSON.stringify({ title }) }),
  // ---- media lifecycle ----
  storageCapabilities: (): Promise<StorageCapabilities> => req('/storage/capabilities'),
  mediaObjects: (q: { limit?: number; state?: string; channelId?: string; recordingId?: string } = {}):
    Promise<{ objects: MediaObjectRow[]; count: number }> => {
    const p = new URLSearchParams()
    if (q.limit) p.set('limit', String(q.limit))
    if (q.state) p.set('state', q.state)
    if (q.channelId) p.set('channelId', q.channelId)
    if (q.recordingId) p.set('recordingId', q.recordingId)
    return req(`/storage/objects?${p.toString()}`)
  },
  mediaObject: (id: string): Promise<any> => req(`/storage/objects/${id}`),
  restoreMedia: (id: string, speed?: 'expedited' | 'standard' | 'bulk'): Promise<any> =>
    req(`/storage/objects/${id}/restore`, { method: 'POST', body: JSON.stringify({ speed }) }),
  holdMedia: (id: string, hold: boolean, reason?: string): Promise<MediaObjectRow> =>
    req(`/storage/objects/${id}/hold`, { method: 'POST', body: JSON.stringify({ hold, reason }) }),
  retentionRules: (): Promise<{ rules: RetentionRuleRow[]; capabilities: StorageCapabilities }> =>
    req('/storage/retention'),
  saveRetentionRule: (b: {
    ruleId?: string; name: string; channelId?: string; eventId?: string
    accountScope?: boolean; appliesTo?: 'recording' | 'asset' | 'both'
    stages: RetentionStageInput[]
  }): Promise<RetentionRuleRow> => req('/storage/retention', { method: 'PUT', body: JSON.stringify(b) }),
  previewSweep: (): Promise<SweepPreview> => req('/storage/retention/preview', { method: 'POST' }),

  recordingDownload: (id: string): Promise<{ status: 'exporting' | 'ready'; url?: string; message?: string }> =>
    req(`/recordings/${id}/download`),
  // ---- VOD library ----
  vodAssets: (published?: boolean): Promise<VodAssetRow[]> =>
    req(`/vod${published === undefined ? '' : `?published=${published}`}`),
  vodAsset: (id: string): Promise<any> => req(`/vod/${id}`),
  patchVodAsset: (id: string, b: { title?: string; published?: boolean }): Promise<any> =>
    req(`/vod/${id}`, { method: 'PUT', body: JSON.stringify(b) }),
  publishToPortal: (id: string): Promise<any> =>
    req(`/publications/vod/${id}/publish`, { method: 'POST', body: JSON.stringify({ platform: 'portal' }) }),

  // ---- loops & fillers ----
  fillerAssets: (kind?: 'slate' | 'loop'): Promise<FillerAsset[]> =>
    req(`/filler-assets${kind ? `?kind=${kind}` : ''}`),
  patchFillerAsset: (id: string, b: { name?: string }): Promise<FillerAsset> =>
    req(`/filler-assets/${id}`, { method: 'PATCH', body: JSON.stringify(b) }),
  deleteFillerAsset: (id: string): Promise<null> =>
    req(`/filler-assets/${id}`, { method: 'DELETE' }),

  // ---- monitoring ----
  /** The whole live board in one request: the fan-out lives on the server. */
  liveBoard: (): Promise<LiveBoard> => req('/monitoring/live'),
  /** Problems, ranked, across every subsystem that can quietly go wrong. */
  monitoringOverview: (): Promise<MonitoringOverview> => req('/monitoring/overview'),

  // ---- fleet ----
  /** Servers carrying this tenant's live work, with their latest readings. */
  fleetHosts: (): Promise<{ hosts: FleetHost[] }> => req('/fleet/hosts'),
  /** Billable TIME. Not money: the rate table is indicative and stays server side. */
  fleetUsage: (period: 'day' | 'week' | 'month' | 'year' = 'day', limit = 30): Promise<FleetUsage> =>
    req(`/fleet/usage?period=${period}&limit=${Math.round(limit)}`),
  /** One stream's usage, for the detail pages. */
  streamUsage: (id: string): Promise<StreamUsage> => req(`/fleet/usage/stream/${encodeURIComponent(id)}`),
  /** Recent telemetry for one host, oldest first, for a sparkline. */
  hostSamples: (id: string): Promise<{ samples: Array<HostMetrics & { tasks: number | null }> }> =>
    req(`/fleet/hosts/${encodeURIComponent(id)}/samples`),

  // ---- analytics ----
  /** The whole reporting page in one read, from rollups only. */
  analyticsOverview: (days = 30): Promise<AnalyticsOverview> =>
    req(`/analytics/overview?days=${Math.round(days)}`),
  /** Concurrency NOW. Goes stale in seconds, so the page polls it. */
  analyticsRealtime: (): Promise<{ total_concurrent: number; streams: LiveStreamRow[] }> =>
    req('/analytics/realtime'),

  // ---- analytics retention ----
  analyticsRetention: (): Promise<AnalyticsRetention> => req('/analytics/retention'),
  setAnalyticsRetention: (rawRetentionDays: number | null): Promise<AnalyticsRetention> =>
    req('/analytics/retention', { method: 'PUT', body: JSON.stringify({ rawRetentionDays }) }),
  sweepAnalyticsRetention: (): Promise<any> =>
    req('/analytics/retention/sweep', { method: 'POST' }),

  // ---- review and QC ----
  reviewQueue: (): Promise<{ queue: ReviewQueueRow[]; count: number }> => req('/vod/review/queue'),
  assetReview: (id: string): Promise<AssetReview> => req(`/vod/${id}/review`),
  decideReview: (id: string, to: ReviewStateId, note?: string): Promise<any> =>
    req(`/vod/${id}/review`, { method: 'POST', body: JSON.stringify({ to, note }) }),
  rerunQc: (id: string): Promise<{ jobId: string; state: string }> =>
    req(`/vod/${id}/qc`, { method: 'POST' }),

  /** Keyframe thumbnails across a window: the video half of the media lane. */
  channelThumbs: (id: string, from: number, to: number, count: number, prime = true): Promise<ThumbStrip> =>
    req(`/channels/${id}/thumbs?from=${Math.round(from)}&to=${Math.round(to)}&count=${count}${prime ? '&prime=1' : ''}`),
  /** What a finished clip was built from, back to the physical segments. */
  clipProvenance: (assetId: string): Promise<ClipProvenance> => req(`/vod/${assetId}/provenance`),
  /** The reverse: what a capture produced, and whether it is safe to prune. */
  recordingDerived: (id: string): Promise<DerivedAssets> => req(`/recordings/${id}/derived`),

  fileFolders: (): Promise<{ folders: { path: string; name: string; count: number }[] }> => req('/files/folders'),
  createFolder: (path: string): Promise<{ path: string }> => req('/files/folders', { method: 'POST', body: JSON.stringify({ path }) }),
  uploadFile: (b: { folder?: string; name: string; kind?: string; contentType?: string; tags?: string[]; dataBase64: string }): Promise<MediaFile> =>
    req('/files', { method: 'POST', body: JSON.stringify(b) }),
  patchFile: (id: string, b: { name?: string; folder?: string; kind?: string; tags?: string[]; version?: number }): Promise<MediaFile> =>
    req(`/files/${id}`, { method: 'PATCH', body: JSON.stringify(b) }),
  // ---- radio: audio-only stations (channels with kind='radio') ----
  radioStations: (): Promise<RadioStationRow[]> => req('/radio'),
  radioStation: (id: string): Promise<RadioStationDetail> => req(`/radio/${id}`),
  radioStartStop: (id: string, action: 'start' | 'stop') =>
    req(`/radio/${id}/${action}`, { method: 'POST' }),
  // second, explicit step: open/close PUBLIC delivery (same contract as channels)
  radioSetAir: (id: string, on: boolean): Promise<{ id: string; on_air: boolean; publicUrls: RadioOutputs | null }> =>
    req(`/radio/${id}/air`, { method: 'POST', body: JSON.stringify({ on }) }),
  // server-measured levels: the visualiser moves whether or not anyone listens
  radioLevels: (id: string, limit = 30): Promise<RadioLevelsFeed> => req(`/radio/${id}/levels?limit=${limit}`),
  radioQc: (id: string): Promise<{ stationId: string; health: PipelineHealth; qc: RadioQc; statusBoard: Record<string, string> }> =>
    req(`/radio/${id}/qc`),
  radioEvents: (id: string): Promise<{ stationId: string; entries: { ts: string; level: string; title: string; detail: string }[] }> =>
    req(`/radio/${id}/events`),
  radioNowPlaying: (id: string): Promise<RadioNowPlaying> => req(`/radio/${id}/nowplaying`),
  radioLog: (id: string, p: { from?: string; to?: string; q?: string; class?: RadioClass; limit?: number } = {}): Promise<RadioLog> => {
    const qs = new URLSearchParams()
    if (p.from) qs.set('from', p.from)
    if (p.to) qs.set('to', p.to)
    if (p.q) qs.set('q', p.q)
    if (p.class) qs.set('class', p.class)
    if (p.limit) qs.set('limit', String(p.limit))
    return req(`/radio/${id}/log` + (qs.toString() ? '?' + qs : ''))
  },

  // ---- admin: who am I + access model (drives nav/button gating) ----
  me: (): Promise<Me> => req('/auth/me'),

  // ---- admin: user management (admin+ only) ----
  users: (): Promise<UserRow[]> => req('/users'),
  createUser: (b: { email: string; password: string; role: TenantRole; userGroupId?: string | null }): Promise<UserRow> =>
    req('/users', { method: 'POST', body: JSON.stringify(b) }),
  patchUser: (id: string, b: { role?: TenantRole; status?: 'active' | 'disabled'; userGroupId?: string | null }): Promise<UserRow> =>
    req(`/users/${id}`, { method: 'PATCH', body: JSON.stringify(b) }),

  // ---- admin: user groups (per-feature access none/view/manage) ----
  userGroups: (): Promise<UserGroupRow[]> => req('/user-groups'),
  createUserGroup: (b: { name: string; description?: string; permissions: Record<string, AccessLevel> }): Promise<UserGroupRow> =>
    req('/user-groups', { method: 'POST', body: JSON.stringify(b) }),
  patchUserGroup: (id: string, b: { name?: string; description?: string | null; permissions?: Record<string, AccessLevel> }): Promise<UserGroupRow> =>
    req(`/user-groups/${id}`, { method: 'PATCH', body: JSON.stringify(b) }),
  deleteUserGroup: async (id: string): Promise<void> => {
    const r = await fetch('/api/user-groups/' + id, { method: 'DELETE', headers: { authorization: `Bearer ${getToken()}` } })
    if (!r.ok && r.status !== 204) throw new Error(String(r.status))
  },

  // ---- admin: apps & API keys ----
  apps: (): Promise<AppReg[]> => req('/apps'),
  app: (id: string): Promise<AppReg & { keys: ApiKeyRow[] }> => req(`/apps/${id}`),
  createApp: (b: { name: string; type: AppType; restrictions?: Record<string, any> }): Promise<AppReg & { publishableKey: MintedKey }> =>
    req('/apps', { method: 'POST', body: JSON.stringify(b) }),
  updateApp: (id: string, b: { name?: string; restrictions?: Record<string, any>; enabled?: boolean }): Promise<AppReg> =>
    req(`/apps/${id}`, { method: 'PUT', body: JSON.stringify(b) }),
  rotateAppKey: (id: string): Promise<MintedKey> => req(`/apps/${id}/keys`, { method: 'POST' }),
  revokeApiKey: async (keyId: string): Promise<void> => {
    const r = await fetch('/api/apps/keys/' + keyId, { method: 'DELETE', headers: { authorization: `Bearer ${getToken()}` } })
    if (!r.ok && r.status !== 204) throw new Error(String(r.status))
  },
  createSecretKey: (): Promise<MintedKey> => req('/apps/secret-keys', { method: 'POST' }),
  allKeys: (): Promise<AccountKeyRow[]> => req('/apps/keys'),

  // ---- platform (system admin): client accounts ----
  platformAccounts: (): Promise<PlatformAccountRow[]> => req('/platform/accounts'),
  platformCreateAccount: (b: {
    name: string; planTier?: 'standard' | 'pro' | 'enterprise'
    maxChannels?: number; maxConcurrentSources?: number
    ownerEmail: string; ownerPassword: string
  }): Promise<{ account: PlatformAccountRow; owner: { id: string; email: string }; credentials: { email: string; password: string }; note: string }> =>
    req('/platform/accounts', { method: 'POST', body: JSON.stringify(b) }),
  platformPatchAccount: (id: string, b: {
    name?: string; planTier?: 'standard' | 'pro' | 'enterprise'
    maxChannels?: number; maxConcurrentSources?: number; status?: 'active' | 'suspended'
  }): Promise<PlatformAccountRow> => req(`/platform/accounts/${id}`, { method: 'PATCH', body: JSON.stringify(b) }),

  deleteFile: async (id: string, opts: { confirm?: boolean; force?: boolean } = {}): Promise<{ ok: boolean; status: number; body?: any }> => {
    const qs = new URLSearchParams()
    if (opts.confirm) qs.set('confirm', 'true')
    if (opts.force) qs.set('force', 'true')
    const r = await fetch('/api/files/' + id + (qs.toString() ? '?' + qs : ''), {
      method: 'DELETE', headers: { authorization: `Bearer ${getToken()}` },
    })
    if (r.status === 204) return { ok: true, status: 204 }
    let body: any = null; try { body = await r.json() } catch { /* */ }
    return { ok: false, status: r.status, body }
  },
}

// ---- radio types --------------------------------------------------------------
export type RadioClass = 'song' | 'ad' | 'content'
export interface RadioOutputsCfg { mp3?: boolean; hls?: boolean; dash?: boolean }
export interface RadioCfg {
  outputs?: RadioOutputsCfg
  bitrateKbps?: number
  metadataCapture?: boolean
  transcode?: boolean
  transcription?: boolean
}
export interface RadioPipelineState {
  running: boolean; runId?: string; startedAt?: number
  sourceCodec?: string | null; listeners?: number
  icy?: RadioIcyState | null
}
export interface RadioIcyState {
  connected: boolean
  station: { name?: string; genre?: string; url?: string; bitrateKbps?: number; contentType?: string }
  title: string | null; streamUrl: string | null
  class: RadioClass | null; since: number | null; changes: number; lastError: string | null
}
export type SignalVerdict = 'audio' | 'quiet' | 'silent' | 'static' | 'unknown'
export interface RadioOutputs { mp3: string | null; hls: string | null; dash: string | null }
export interface RadioLevelSample {
  t: number; peakDb: number; rmsDb: number; crestDb: number
  entropy: number; silence: boolean; verdict: SignalVerdict
  frames: number[]     // ~100ms momentary loudness (EBU R128 M, LUFS)
  peaks?: number[]     // ~100ms true peak (dBFS) — this is what the waveform draws
}
export interface RadioLevelsFeed {
  stationId: string; running: boolean; verdict: SignalVerdict; lastSampleAt: number | null
  level: { peakDb: number; rmsDb: number; crestDb: number; entropy: number } | null
  samples: RadioLevelSample[]
}
export interface RadioQc {
  verdict: SignalVerdict; lastSampleAt: number | null
  checks: { ok: number; failed: number }
  issues: { code: string; message: string; at: number }[]
  segments: number; outputFreshMs: number | null
  silenceSinceMs: number | null; staticSinceMs: number | null
  level: { peakDb: number; rmsDb: number; crestDb: number; entropy: number } | null
}
export interface RadioStationRow {
  id: string; name: string; status: string; group_id: string; group_name?: string
  kind: 'radio'; radio_config: RadioCfg | null
  recording_enabled?: boolean; recording_retention_sec?: number | string | null
  brand_ref?: string | null; on_air?: boolean; created_at: string; version: number
  pipeline: RadioPipelineState
  nowPlaying: string | null; nowPlayingClass: RadioClass | null
  outputs: RadioOutputs
  publicUrls?: RadioOutputs
  pipelineState?: PipelineHealth['overall']
  onAir?: boolean
  signal?: SignalVerdict
}
export interface RadioLogEntry {
  id: string; title: string; starts_at: string; ends_at: string; status: string
  class: RadioClass | null; stream_url: string | null
}
export interface RadioStationDetail extends RadioStationRow {
  sources: { id: string; role: string; protocol: string; ingest_url: string | null; stream_key: string | null; status?: string }[]
  icy: RadioIcyState | null
  openRecording: { id: string; start_epoch_ms: number | string; status: string } | null
  recentLog: (RadioLogEntry & { metadata?: any })[]
  health: PipelineHealth
  qc: RadioQc
  statusBoard: Record<string, string>
  log: { ts: string; level: string; title: string; detail: string }[]
  publicAvailable: boolean
}
export interface RadioNowPlaying {
  running: boolean; listeners: number
  station: RadioIcyState['station'] | null
  title: string | null; class: RadioClass | null; since: number | null; streamUrl: string | null
  entry: { id: string; title: string; starts_at: string; metadata?: any } | null
}
export interface RadioLog {
  stationId: string; from: string; to: string
  counts: Partial<Record<RadioClass, number>>
  entries: RadioLogEntry[]
}

// ---- admin / access model types --------------------------------------------
export type TenantRole = 'viewer' | 'operator' | 'admin' | 'owner'
export type AccessLevel = 'none' | 'view' | 'manage'

export interface Me {
  id: string; email?: string; role: string; status?: string
  platformRole?: string | null
  userGroupId?: string | null; userGroupName?: string | null
  account?: { id: string; name: string; plan: string; status: string }
  features: Record<string, AccessLevel>
  model: { roles: string[]; features: string[]; levels: AccessLevel[]; notes: string[] }
}

export interface UserRow {
  id: string; email: string; role: TenantRole; status: 'active' | 'disabled' | 'invited'
  is_platform?: boolean
  user_group_id: string | null; user_group_name?: string | null
  created_at: string
}

export interface UserGroupRow {
  id: string; name: string; description: string | null
  permissions: Record<string, AccessLevel>
  member_count?: number
  created_at: string
}

export type AppType = 'web' | 'ios' | 'android' | 'tv' | 'roku' | 'server'
export interface AppReg {
  id: string; name: string; type: AppType
  restrictions: Record<string, any>; enabled: boolean
  created_at: string; updated_at?: string
}
export interface ApiKeyRow {
  id: string; key_prefix: string; kind: 'secret' | 'publishable'
  scopes: string[]; enabled: boolean
  last_used_at: string | null; request_count: number | string
  created_at?: string
}
/** A freshly minted key: `key` is the RAW value, shown once, never retrievable again. */
export interface MintedKey extends Omit<ApiKeyRow, 'enabled' | 'last_used_at' | 'request_count'> {
  key: string
}
export interface AccountKeyRow extends ApiKeyRow {
  app_id: string | null; app_name: string | null
}

export interface PlatformAccountRow {
  id: string; name: string; plan_tier: string
  max_channels: number; max_concurrent_sources?: number
  status?: 'active' | 'suspended'
  channels?: number | string; users?: number | string
  created_at?: string
}

export interface EventSourceRow {
  id?: string; role: 'primary' | 'backup'; protocol: string
  ingest_url: string | null; stream_key: string | null; status?: string
}
export interface EventRow {
  id: string; group_id: string; name: string; status: string
  scheduled_start: string; scheduled_end: string
  server_start: string | null; server_stop: string | null
  public_start: string | null; public_end: string | null
  actual_start?: string | null; actual_end?: string | null
  recording_enabled?: boolean
  recording_retention_days: number | null; recording_retention_sec?: number | null
  auto_vod?: boolean
  input_failover_enabled?: boolean; auto_failback?: boolean
  input_loss_behavior?: string; filler_slate_ref?: string | null
  version: number; created_at: string
  inputs?: EventSourceRow[]
}
export interface EventCreateBody {
  groupId: string; name: string
  scheduledStart: string; scheduledEnd: string
  serverStart?: string; serverStop?: string
  publicStart?: string; publicEnd?: string
  purchasingMode?: 'on_demand' | 'reserved' | 'spot_fallback'
  recordingEnabled?: boolean; recordingRetentionSec?: number | null
  autoVod?: boolean
  sources?: { role: 'primary' | 'backup'; protocol: string; ingestUrl?: string; streamKey?: string }[]
  inputFailoverEnabled?: boolean; autoFailback?: boolean
  inputLossBehavior?: 'none' | 'slate' | 'vod_loop' | 'last_frame' | 'black'
  fillerSlateRef?: string | null
}
export interface EventPatchBody extends Partial<Omit<EventCreateBody, 'groupId'>> { version?: number }

export interface EpgOwner { kind: 'channel' | 'event'; id: string }
export interface EpgOwnerRow {
  kind: 'channel' | 'event'; id: string; name: string; status: string
  programme_count: number; first_at: string | null; last_at: string | null
  auto_clip_count: number; next_title: string | null; next_at: string | null
}
export interface ProgrammeRow {
  id: string; channel_id: string | null; event_id: string | null
  title: string; starts_at: string; ends_at: string; status: string
  actual_start: string | null; actual_end: string | null
  auto_vod: boolean; geo_mode: 'worldwide' | 'allow' | 'block'; geo_countries: string[]
  replacement_kind: 'none' | 'slate' | 'loop' | 'vod'; replacement_ref: string | null
  clip_status: 'none' | 'firing' | 'created' | 'error'; clip_asset_id: string | null; clip_error: string | null
  metadata: Record<string, any>; series_id: string | null
}
export interface ProgrammeBody {
  title: string; startsAt: string; endsAt?: string
  autoVod?: boolean
  geoMode?: 'worldwide' | 'allow' | 'block'; geoCountries?: string[]
  replacementKind?: 'none' | 'slate' | 'loop' | 'vod'; replacementRef?: string | null
  metadata?: Record<string, any>
}
export interface ProgrammeConflict {
  a_id: string; a_title: string; b_id: string; b_title: string
  overlap_start: string; overlap_end: string
}

/* ---- the VoD lifecycle of a programme ------------------------------------ */

/**
 * Where a slot is between "will be recorded" and "is a VOD asset".
 *
 *   manual       has not aired, and will NOT auto-convert
 *   scheduled    has not aired, and WILL auto-convert when it ends
 *   converting   the scheduler has claimed it right now
 *   converted    there is an asset
 *   failed       the automatic attempt errored; carries the reason
 *   convertible  AIRED, media still covers it, no asset. Still convertible,
 *                and the only state with a deadline attached
 *   unavailable  aired, and nothing on disk covers it any more
 */
export type VodState =
  | 'manual' | 'scheduled' | 'converting' | 'converted'
  | 'failed' | 'convertible' | 'unavailable'

export interface ProgrammeVod {
  id: string
  state: VodState
  coveragePct: number
  coveredMs: number
  assetId: string | null
  assetTitle: string | null
  assetState: string | null
  error: string | null
  /** When the material behind a convertible slot is due to be swept. Null
   *  means the owner keeps recordings indefinitely. */
  expiresAt: string | null
  future: boolean
}

export interface RecordingRow {
  id: string; kind: 'event' | 'channel_day' | string
  channel_id: string | null; event_id: string | null; source_name: string | null
  title: string | null; status: 'recording' | 'complete' | 'error' | string
  /** Derived server-side from the source, not from `kind`. */
  source_type?: RecordingSourceType
  start_epoch_ms: number | string; end_epoch_ms: number | string | null
  duration_ms: number | string | null; expires_at: string | null
  vod_count?: number
  matched_by?: 'title' | 'programme' | 'transcript' | null
}

export interface TranscriptSearch {
  recordingId: string
  languages: string[]
  entries: number
  matches: { tMs: number; endMs: number; lang: string; text: string; approx: boolean }[]
}

export interface RecordingProgramme {
  id: string; title: string; startMs: number; endMs: number; asRun: boolean; status: string
  /** radio now-playing entries carry song/ad/content; EPG programmes do not */
  class?: 'song' | 'ad' | 'content' | null
  source?: string
}

export interface WaveBucket { t: number; peak: number; rms: number }
export interface Waveform {
  streamId: string; from: number; to: number; bucketMs: number
  mode: 'exact' | 'sampled'
  complete: boolean; pending: number
  priming?: boolean       // a background pass is still measuring the recording
  buckets: (WaveBucket | null)[]
}

export interface RecordingTimeline {
  recordingId: string; streamId: string; kind: string; sourceName: string | null
  startMs: number; endMs: number | null; live: boolean; hasAudio: boolean
  audioOnly?: boolean   // radio recordings: player shows the audio visualiser
  spans: { runId: string; startMs: number; endMs: number; segments: number }[]
}


// ---- media lifecycle: what exists, where it lives, what happens next -------
export type StorageTierId =
  | 'local' | 's3_standard' | 's3_ia' | 's3_glacier_ir'
  | 's3_glacier_flexible' | 's3_deep_archive'
export type RetentionActionId = 'keep' | 'to_cold' | 'to_archive' | 'delete'

export interface StorageCapabilities {
  driver: 'local' | 's3'
  tiers: StorageTierId[]
  archiveEnabled: boolean
  actions: RetentionActionId[]
  defaultColdTier: StorageTierId | null
  defaultArchiveTier: StorageTierId | null
  /** Why archiving is unavailable, when it is. Shown rather than left to guess. */
  archiveUnavailableReason: string | null
  defaultLadder: { afterDays: number; action: RetentionActionId; targetTier?: StorageTierId | null }[]
}

export interface MediaLocationRow {
  id?: string; tier: StorageTierId; uri: string
  bytes: number | string | null; verified_at?: string | null
}

export interface MediaObjectRow {
  id: string
  logical_key: string
  kind: string
  rendition: string | null
  /** Can it be read right now, and if not what is happening. Separate from the
   *  TIER, which says where the bytes are and what reading them costs. */
  state: 'pending' | 'writing' | 'available' | 'archiving' | 'archived'
       | 'restoring' | 'restored' | 'deleting' | 'deleted'
  bytes: number | string | null
  duration_ms: number | string | null
  segment_count: number | null
  hold: boolean
  hold_reason: string | null
  restore_expected_by: string | null
  restore_expires_at: string | null
  source_name: string | null
  recording_title: string | null
  locations: MediaLocationRow[] | null
}

export interface RetentionStageInput {
  afterDays: number; action: RetentionActionId; targetTier?: StorageTierId | string
}

export interface RetentionRuleRow {
  id: string
  account_id: string | null; channel_id: string | null; event_id: string | null
  name: string; applies_to: 'recording' | 'asset' | 'both'; enabled: boolean
  stages: { id?: string; afterDays: number; action: RetentionActionId; targetTier: StorageTierId | null }[]
}

export interface SweepPreview {
  dryRun: boolean; considered: number; cooled: number; archived: number
  deleted: number; skippedOnHold: number; failed: number; unavailable: number
}

/** One frame of the video media lane's filmstrip. */
export interface Thumb {
  /** The instant the frame is actually FROM, not the slot it was asked for. */
  t: number
  url: string
  runId: string
  seq: number
}
export interface ThumbStrip {
  streamId: string
  from: number; to: number
  slotMs: number
  width: number; height: number
  complete: boolean
  pending: number
  priming: boolean
  thumbs: (Thumb | null)[]
}

// ---- review and QC --------------------------------------------------------
export type ReviewStateId = 'draft' | 'in_review' | 'changes_requested' | 'approved' | 'rejected'

/** What a machine measured, not what anyone decided. */
export interface QcFinding {
  check_name: string
  severity: 'info' | 'warning' | 'error'
  from_ms: number | null
  to_ms: number | null
  measured: string | null
  expected: string | null
  message: string
  at: string
}

export interface ReviewDecisionRow {
  at: string
  actor_label: string
  from_state: ReviewStateId | null
  to_state: ReviewStateId
  note: string | null
  /** Set when the decision was taken with QC findings outstanding. The mark that
   *  makes a soft gate mean something. */
  overrode_qc: boolean
  qc_state_at_decision: string | null
}

export interface AssetReview {
  assetId: string
  state: ReviewStateId
  reviewedAt: string | null
  qc: { state: string | null; at: string | null; findings: QcFinding[] }
  history: ReviewDecisionRow[]
  gate: {
    allowed: boolean
    code: 'ok' | 'not_approved' | 'qc_failed'
    message: string
    reviewState: ReviewStateId
    qcState: string | null
    wouldOverride: boolean
  }
}

export interface ReviewQueueRow {
  id: string
  title: string | null
  kind: string
  review_state: ReviewStateId
  qc_state: string | null
  qc_errors: number
  qc_warnings: number
  created_at: string
  duration_ms: number | string | null
  start_epoch_ms: number | string
  end_epoch_ms: number | string
  source_name: string | null
  source_block_count: number | null
  source_coverage_pct: number | string | null
  recording_id?: string | null
}

/** What is kept, and for how long. Reports and raw events are not the same
 *  thing and do not have the same lifetime. */
export interface AnalyticsRetention {
  rawRetentionDays: number | null
  raw: { sessions: number; oldest: string | null; newest: string | null }
  reports: { days: number; sealed: number; oldest: string | null }
  note: string
}

/** One stream on the live board. The gates are the SAME five-gate health the
 *  detail pages compute, so the board can never disagree with the page. */
export interface LiveStream {
  id: string
  kind: 'tv' | 'radio' | 'event'
  name: string
  groupName: string | null
  status: string
  onAir: boolean
  overall: 'idle' | 'starting' | 'ready' | 'onair' | 'degraded' | 'error' | 'stopped'
  gates: Gate[]
  primaryError: { gate: string; label: string; message: string } | null
  /** Null unless the SERVER gate agrees something is up: an instance row
   *  outlives a crashed encoder, and reporting from it alone lies. */
  uptimeMs: number | null
  orphanedInstance: boolean
  concurrent: number
  activeSource: string | null
  fallbackInUse: boolean
  fillerInUse: boolean
  reportAgeMs: number | null
  href: string
  /** The ORIGIN manifest, not the public URL: multiview monitors what the
   *  encoder is producing, whether or not the stream has been published. */
  previewUrl: string
  audioOnly: boolean
}

export interface LiveBoard {
  streams: LiveStream[]
  counts: Record<string, number>
  running: number
  onAir: number
  concurrent: number
}

export type AlertSeverity = 'critical' | 'serious' | 'warning'
export interface FleetAlert {
  id: string
  severity: AlertSeverity
  source: 'pipeline' | 'jobs' | 'media' | 'qc' | 'publishing' | 'uploads' | 'capacity'
  title: string
  detail: string
  href: string | null
  at: string | null
}

export interface FleetEvent {
  id: string
  ts: string
  type: string
  name: string | null
  kind: string
  ownerId: string | null
  detail: string
}

/** What needs attention, not what exists. Every entry is a problem. */
export interface MonitoringOverview {
  generatedAt: string
  fleet: {
    total: number; running: number; onAir: number
    error: number; degraded: number; concurrent: number
  }
  alerts: FleetAlert[]
  counts: { critical: number; serious: number; warning: number }
  feed: FleetEvent[]
}

/** One day of the account-scope rollup. `sealed` says the figures are final:
 *  an unsealed day is still moving and must not be read as a finished trend. */
export interface AnalyticsDay {
  day: string
  views: number
  uniques: number
  peakConcurrent: number
  watchSeconds: number
  blocked: number
  sealed: boolean
}

/** A stream carrying viewers right now. Live, not rolled up. */
export interface LiveStreamRow {
  asset_kind: string
  asset_id: string
  concurrent: number
  updated_at?: string
}

/** Everything the Analytics page draws, read entirely from rollups so it keeps
 *  answering after the raw sessions behind it have been pruned. */
export interface AnalyticsOverview {
  windowDays: number
  daily: AnalyticsDay[]
  totals: {
    views: number
    uniques: number
    watchHours: number
    blocked: number
    peakConcurrent: number
  }
  liveConcurrent: number
  liveStreams: LiveStreamRow[]
  top: Array<{
    kind: string
    id: string
    name: string
    views: number
    watchHours: number
    peakConcurrent: number
  }>
  byApp: Record<string, number>
  byDevice: Record<string, number>
  byGeo: Record<string, number>
}

/** A slate (a still) or a loop (a short video): what a channel falls back to
 *  when its input goes away. */
export interface FillerAsset {
  id: string
  kind: 'slate' | 'loop'
  name: string
  source_key: string | null
  width: number | null
  height: number | null
  duration_ms: number | string | null
  poster_key: string | null
  status: 'uploading' | 'processing' | 'ready' | 'error'
  bytes: number | string | null
  content_type: string | null
  filename: string | null
  uploaded_at: string | null
  error: string | null
  created_at: string
  updated_at: string
}

export interface VodAssetRow {
  id: string; kind: 'clip' | 'full_event' | string; title: string | null
  recording_id: string | null; start_epoch_ms: number | string; end_epoch_ms: number | string
  duration_ms: number | string | null; output_kind?: string | null
  thumb_status?: string | null; created_at: string
  /** Written when the clip is built, from the same resolution that produced the
   *  media. Absent on assets made before provenance was recorded. */
  source_block_count?: number | null; source_run_count?: number | null
  source_container_count?: number | null; source_segment_count?: number | null
  source_coverage_pct?: number | string | null; build_strategy?: string | null
  /** Set on the list: an asset was re-cut after it was published, so the copy
   *  out there is older than the one here. */
  has_stale_publication?: boolean
  publication_count?: number
  published?: boolean
  review_state?: ReviewStateId
  qc_state?: string | null
  source_name?: string | null
}

/** One contiguous stretch of source media inside a finished clip. */
export interface ProvenanceBlock {
  ordinal: number
  runId: string
  blockIndex: number
  rendition: string
  segments: { first: number; last: number; count: number }
  source: { fromMs: number; toMs: number }
  clip: { offsetMs: number; durationMs: number }
  trimmed: { head: boolean; tail: boolean }
  recording: { id: string; title: string | null; status: string } | null
  container: { id: string; day: string; tz: string } | null
  /** False once retention has taken the source media away: the clip still plays,
   *  but it can no longer be re-cut at a different length. */
  sourceMediaPresent: boolean
}

export interface ClipProvenance {
  assetId: string
  title: string | null
  streamId: string | null
  requested: { fromMs: number; toMs: number; ms: number }
  counts: {
    blocks: number; runs: number; containers: number; segments: number
    recordingsLinked: number; recordingsGone: number
  }
  coveragePct: number | null
  gapMs: number | null
  buildStrategy: string | null
  builtAt: string | null
  spansBroadcastDays: boolean
  blocks: ProvenanceBlock[]
  /** False for assets produced before the chain was recorded, which is not the
   *  same as an asset with no sources. */
  recorded: boolean
  note: string | null
}

export interface DerivedAssets {
  recordingId: string
  assets: { assetId: string; title: string | null; published: boolean; fromMs: number; toMs: number; segments: number; blocks: number }[]
  counts: { total: number; published: number }
  safeToPrune: boolean
}

/** Authenticated range-playback master manifest for a recording (bearer goes via
 *  the player's xhrSetup for /api URLs; segments themselves are public /origin). */
export function recordingRangeUrl(recordingId: string, fromMs: number, toMs: number) {
  return `/api/recordings/${recordingId}/range/master.m3u8?from=${Math.round(fromMs)}&to=${Math.round(toMs)}`
}

export interface ShareLinkRow {
  id: string; resource_kind: 'vod' | 'channel' | 'event'; resource_id: string
  label: string | null; access_type: string; expires_at: string
  max_views: number | null; view_count: number; first_opened_at: string | null
  last_viewed_at: string | null; revoked: boolean; created_at: string; token_prefix: string
}

export interface MediaFile {
  id: string; account_id: string; kind: string; path: string; folder: string; name: string
  content_type: string | null; size_bytes: number | null; width: number | null; height: number | null
  tags: string[]; store_key: string; status: string; version: number; created_at: string; url: string
}

export interface IngestProtocol {
  id: string; label: string; ingest: 'push' | 'pull'
  urlLabel: string; urlPlaceholder: string; urlExample: string; urlPattern?: string
  streamKey: { show: boolean; label?: string; placeholder?: string }
  extraFields?: { key: string; label: string; type: string; required?: boolean; placeholder?: string; hint?: string }[]
  hint: string; packageFriendly: boolean
}

// origin URLs are same-origin under /origin (proxied by Vite to the API in dev)
export function originUrl(path: string) { return path.startsWith('/origin') ? path : `/origin${path}` }

// Resized preview via the image service: /img/<WxH>[,fit]/<store-key>. `url` is a
// library URL like '/library/<acct>/<path>'; the store key is that without the slash.
export function thumbUrl(libraryUrl: string, w: number, h: number, fit: 'cover' | 'inside' = 'cover') {
  const key = libraryUrl.replace(/^\//, '')
  if (!key.startsWith('library/')) return libraryUrl
  return `/img/${w}x${h},${fit}/${key}`
}
