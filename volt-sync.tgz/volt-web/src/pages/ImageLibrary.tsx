import { useEffect, useRef, useState } from 'react'
import { api, thumbUrl, type MediaFile } from '../api'
import { enqueueUploads, useUploads } from '../uploads'
import { pressable } from '../a11y'

const KINDS = ['all', 'slate', 'watermark', 'poster', 'brand', 'other'] as const
const ASSIGNABLE = ['slate', 'watermark', 'poster', 'brand', 'other'] // user-assignable usage types
const STD_FOLDERS = ['slates', 'watermarks', 'brands', 'posters']

function inferKind(folder: string): string {
  const top = folder.split('/')[0]
  if (top === 'slates') return 'slate'
  if (top === 'watermarks') return 'watermark'
  if (top === 'brands') return 'brand'
  if (top === 'posters') return 'poster'
  return 'other'
}
function human(bytes: number | null) {
  if (!bytes) return '—'
  if (bytes < 1024) return bytes + ' B'
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(0) + ' KB'
  return (bytes / 1024 / 1024).toFixed(1) + ' MB'
}

interface Staged { file: File; name: string; kind: string; preview: string }

export default function ImageLibrary() {
  const [folders, setFolders] = useState<{ path: string; name: string; count: number }[]>([])
  const [folder, setFolder] = useState<string>('')
  const [kind, setKind] = useState<string>('all')
  const [q, setQ] = useState('')
  const [files, setFiles] = useState<MediaFile[] | null>(null)
  const [err, setErr] = useState('')
  const [confirm, setConfirm] = useState<{ file: MediaFile; inUse?: any[] } | null>(null)
  const [folderModal, setFolderModal] = useState<null | string>(null)
  const [staged, setStaged] = useState<{ items: Staged[]; folder: string } | null>(null)
  const [preview, setPreview] = useState<MediaFile | null>(null)
  const [builder, setBuilder] = useState<MediaFile | null>(null)
  const [dragging, setDragging] = useState(false)
  const [toast, setToast] = useState('')
  const fileInput = useRef<HTMLInputElement | null>(null)
  const uploads = useUploads()

  function flash(msg: string) { setToast(msg); window.setTimeout(() => setToast(t => (t === msg ? '' : t)), 3200) }

  // refresh the grid as background uploads complete (seq bumps per success)
  useEffect(() => { if (uploads.seq) { loadFolders(); load() } /* eslint-disable-next-line */ }, [uploads.seq])

  async function loadFolders() { try { setFolders((await api.fileFolders()).folders) } catch { /* */ } }
  async function load() {
    try { setErr(''); setFiles(await api.files({ folder: folder || '', recursive: true, kind: kind === 'all' ? undefined : kind, q: q.trim() || undefined })) }
    catch (e: any) { setErr(e.message) }
  }
  useEffect(() => { loadFolders() }, [])
  // folder / kind change reloads immediately; the search term is debounced so typing
  // doesn't fire a request per keystroke (and doesn't flicker the grid to Loading).
  useEffect(() => { setFiles(null); load() /* eslint-disable-next-line */ }, [folder, kind])
  useEffect(() => {
    const t = setTimeout(() => { load() }, 200)
    return () => clearTimeout(t)
    // eslint-disable-next-line
  }, [q])

  // ---- staging: build a review list instead of uploading immediately ---------
  function stageFiles(list: FileList | File[]) {
    const arr = Array.from(list).filter(f => f.type.startsWith('image/'))
    if (!arr.length) { setErr('No image files in that selection'); return }
    const items: Staged[] = arr.map(file => ({ file, name: file.name, kind: inferKind(folder), preview: URL.createObjectURL(file) }))
    setStaged({ items, folder })
  }
  function updateStaged(i: number, patch: Partial<Staged>) {
    setStaged(s => s ? { ...s, items: s.items.map((it, j) => j === i ? { ...it, ...patch } : it) } : s)
  }
  // hand off to the background uploader and close the review panel; progress shows in
  // the topbar indicator and the grid refreshes as each item completes.
  function commitUpload() {
    if (!staged) return
    enqueueUploads(staged.items.map(it => ({ file: it.file, folder: staged.folder, name: it.name, kind: it.kind })))
    const n = staged.items.length
    staged.items.forEach(it => URL.revokeObjectURL(it.preview))
    setStaged(null)
    flash(`Uploading ${n} image${n > 1 ? 's' : ''} in the background…`)
  }

  async function createFolder(name: string) {
    const clean = name.trim().replace(/^\/|\/$/g, '')
    if (!clean) return
    try { await api.createFolder(clean); await loadFolders(); setFolder(clean); setFolderModal(null) }
    catch (e: any) { setErr(e.message) }
  }

  async function changeKind(f: MediaFile, newKind: string) {
    try { const updated = await api.patchFile(f.id, { kind: newKind, version: f.version }); setPreview(updated); await load() }
    catch (e: any) { setErr(e.message) }
  }

  async function doDelete(f: MediaFile, force = false) {
    const r = await api.deleteFile(f.id, { confirm: true, force })
    if (r.ok) { setConfirm(null); setPreview(null); await loadFolders(); await load(); return }
    if (r.status === 409) { setConfirm({ file: f, inUse: r.body?.inUseBy || [] }); return }
    setErr(r.body?.message || r.body?.error || `Delete failed (${r.status})`)
  }

  const shown = files || []

  return (
    <div
      onDragOver={e => { e.preventDefault(); if (!dragging) setDragging(true) }}
      onDragLeave={e => { if (e.currentTarget === e.target) setDragging(false) }}
      onDrop={e => { e.preventDefault(); setDragging(false); if (e.dataTransfer.files?.length) stageFiles(e.dataTransfer.files) }}
      style={{ position: 'relative', minHeight: 400 }}
    >
      <div className="page-head">
        <div><h1>Image Library</h1><p>Watermarks, slates, posters and channel brands. Drag &amp; drop or upload; assign a usage type on the way in.</p></div>
        <div className="spacer" />
        <button className="btn ghost" onClick={() => setFolderModal(folder ? folder + '/' : '')}>+ New folder</button>
        <button className="btn primary" onClick={() => fileInput.current?.click()}>Upload images</button>
        <input ref={fileInput} type="file" accept="image/*" multiple hidden onChange={e => { if (e.target.files) stageFiles(e.target.files); if (fileInput.current) fileInput.current.value = '' }} />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '220px 1fr', gap: 16, alignItems: 'start' }}>
        <div className="card" style={{ padding: 10 }}>
          <FolderRow label="All images" active={folder === ''} onClick={() => setFolder('')} count={folders.reduce((a, f) => a + f.count, 0)} depth={0} />
          {folders.map(f => (
            <FolderRow key={f.path} label={f.name} active={folder === f.path} onClick={() => setFolder(f.path)} count={f.count} depth={f.path.split('/').length} />
          ))}
          {folders.length === 0 && (
            <div style={{ padding: '10px 8px', fontSize: 'var(--fs-sm)', color: 'var(--faint)' }}>
              No folders yet. Quick-create:
              <div className="chipset" style={{ marginTop: 8 }}>
                {STD_FOLDERS.map(name => <div key={name} className="selchip" {...pressable((e: any) => { ((async () => { await api.createFolder(name); await loadFolders(); setFolder(name) }) as any)(e) })} data-a11y-click="">{name}</div>)}
              </div>
            </div>
          )}
        </div>

        <div>
          <div className="filters" style={{ marginBottom: 12, gap: 8, alignItems: 'center' }}>
            <div style={{ position: 'relative', flex: '1 1 320px', maxWidth: 420 }}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ position: 'absolute', left: 11, top: '50%', transform: 'translateY(-50%)', width: 16, height: 16, color: 'var(--faint)', pointerEvents: 'none' }}><circle cx="11" cy="11" r="7" /><path d="m21 21-4-4" /></svg>
              <input className="inp" style={{ width: '100%', paddingLeft: 34 }} placeholder="Search images by name, path or tag…" value={q} onChange={e => setQ(e.target.value)} aria-label="Search images" />
              {q && <button className="xbtn" onClick={() => setQ('')} title="Clear" style={{ position: 'absolute', right: 6, top: '50%', transform: 'translateY(-50%)' }}>✕</button>}
            </div>
            {KINDS.map(k => <div key={k} className={`chip ${kind === k ? 'active' : ''}`} {...pressable((e: any) => { ((() => setKind(k)) as any)(e) })} data-a11y-click="">{k}</div>)}
          </div>

          {err && <div className="err" style={{ marginBottom: 10 }}>{err}</div>}

          {files === null ? <div className="loading">Loading…</div>
            : shown.length === 0 ? (
              <div className="empty" {...pressable((e: any) => { ((() => fileInput.current?.click()) as any)(e) })} data-a11y-click="" style={{ cursor: 'pointer' }}>
                <div className="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="18" height="18" rx="2" /><circle cx="9" cy="9" r="2" /><path d="m21 15-5-5L5 21" /></svg></div>
                <h3>No images here</h3>
                <p>{folder ? `The “${folder}” folder is empty.` : 'Your library is empty.'} Drag images in, or click to upload.</p>
              </div>
            ) : (
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(150px,1fr))', gap: 14 }}>
                {shown.map(f => (
                  <div key={f.id} className="card" style={{ overflow: 'hidden', cursor: 'pointer' }} {...pressable((e: any) => { ((() => setPreview(f)) as any)(e) })} data-a11y-click="">
                    <div style={{ aspectRatio: '16/10', background: 'repeating-conic-gradient(#1a1f2b 0% 25%, #141821 0% 50%) 50% / 16px 16px', display: 'grid', placeItems: 'center' }}>
                      <img src={thumbUrl(f.url, 300, 190)} alt={f.name} loading="lazy" style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain' }} />
                    </div>
                    <div style={{ padding: '9px 11px' }}>
                      <div style={{ fontWeight: 650, fontSize: 'var(--fs-sm)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }} title={f.path}>{f.name}</div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 4 }}>
                        <span className="tag type" style={{ fontSize: 'var(--fs-micro)' }}>{f.kind}</span>
                        <span style={{ fontSize: 'var(--fs-label)', color: 'var(--faint)' }}>{f.width && f.height ? `${f.width}×${f.height}` : ''} · {human(f.size_bytes)}</span>
                      </div>
                      {f.folder && <div style={{ fontSize: 'var(--fs-micro)', color: 'var(--faint)', marginTop: 2 }}>{f.folder}/</div>}
                    </div>
                  </div>
                ))}
              </div>
            )}
        </div>
      </div>

      {/* drag overlay */}
      {dragging && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 50, background: 'rgba(11,15,22,.7)', display: 'grid', placeItems: 'center', pointerEvents: 'none' }}>
          <div style={{ border: '2px dashed var(--brand)', borderRadius: 16, padding: '48px 64px', textAlign: 'center', color: '#dbe6ff', background: 'var(--brand-dim)' }}>
            <div style={{ fontSize: 30, marginBottom: 8 }}>⬇</div>
            <div style={{ fontWeight: 700, fontSize: 'var(--fs-h2)' }}>Drop images to add</div>
            <div style={{ fontSize: 'var(--fs-sm)', color: 'var(--muted)', marginTop: 4 }}>You’ll set the usage type before they upload.</div>
          </div>
        </div>
      )}

      {/* staging / review before commit */}
      {staged && (
        <div className="drawer-scrim" {...pressable((e: any) => { ((() => { staged.items.forEach(it => URL.revokeObjectURL(it.preview)); setStaged(null) }) as any)(e) })} data-a11y-click="">
          <div className="drawer" {...pressable((e: any) => { (((e: any) => e.stopPropagation()) as any)(e) })} data-a11y-click="" style={{ width: 560, maxWidth: '96vw' }}>
            <div className="drawer-h"><div className="t">Add {staged.items.length} image{staged.items.length > 1 ? 's' : ''}</div>
              <button className="xbtn" onClick={() => { staged.items.forEach(it => URL.revokeObjectURL(it.preview)); setStaged(null) }}>✕</button></div>
            <div className="drawer-b">
              <div className="field"><label>Destination folder</label>
                <input className="inp" value={staged.folder} onChange={e => setStaged(s => s ? { ...s, folder: e.target.value.replace(/^\/|\/$/g, '') } : s)} placeholder="(root) or e.g. slates/news" />
              </div>
              <div className="field"><label>Set all to type</label>
                <div className="chipset">
                  {ASSIGNABLE.map(k => <div key={k} className="selchip" onClick={() => setStaged(s => s ? { ...s, items: s.items.map(it => ({ ...it, kind: k })) } : s)}>{k}</div>)}
                </div>
                <div className="hintxt">Pre-filled from the folder. Confirm or change per image below so nothing is stored as the wrong type.</div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {staged.items.map((it, i) => (
                  <div key={i} style={{ display: 'flex', gap: 11, alignItems: 'center', border: '1px solid var(--border)', borderRadius: 11, padding: 9 }}>
                    <img src={it.preview} alt="" style={{ width: 56, height: 42, objectFit: 'cover', borderRadius: 7, background: '#000', flex: 'none' }} />
                    <input className="inp" value={it.name} onChange={e => updateStaged(i, { name: e.target.value })} style={{ flex: 1 }} />
                    <select className="inp" style={{ width: 116 }} value={it.kind} onChange={e => updateStaged(i, { kind: e.target.value })}>
                      {ASSIGNABLE.map(k => <option key={k} value={k}>{k}</option>)}
                    </select>
                    <button className="xbtn" title="Remove" onClick={() => { URL.revokeObjectURL(it.preview); setStaged(s => s ? { ...s, items: s.items.filter((_, j) => j !== i) } : s) }}>✕</button>
                  </div>
                ))}
              </div>
            </div>
            <div className="drawer-f">
              <button className="btn ghost" onClick={() => { staged.items.forEach(it => URL.revokeObjectURL(it.preview)); setStaged(null) }}>Cancel</button>
              <button className="btn primary" disabled={!staged.items.length} onClick={commitUpload}>Upload {staged.items.length}</button>
            </div>
          </div>
        </div>
      )}

      {/* preview / detail with editable type */}
      {preview && (
        <div className="drawer-scrim" {...pressable((e: any) => { ((() => setPreview(null)) as any)(e) })} data-a11y-click="" style={{ alignItems: 'center', justifyContent: 'center' }}>
          <div className="card" {...pressable((e: any) => { (((e: any) => e.stopPropagation()) as any)(e) })} data-a11y-click="" style={{ width: 560, maxWidth: '95vw', padding: 0, overflow: 'hidden' }}>
            <div style={{ background: 'repeating-conic-gradient(#1a1f2b 0% 25%, #141821 0% 50%) 50% / 18px 18px', display: 'grid', placeItems: 'center', maxHeight: 360 }}>
              <img src={thumbUrl(preview.url, 1000, 720, 'inside')} alt={preview.name} style={{ maxWidth: '100%', maxHeight: 360, objectFit: 'contain' }} />
            </div>
            <div style={{ padding: 18 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <div style={{ fontWeight: 700, fontSize: 'var(--fs-h2)' }}>{preview.name}</div>
                <span className="spacer" style={{ flex: 1 }} />
                <button className="xbtn" title="Delete" onClick={() => setConfirm({ file: preview })}>🗑</button>
              </div>
              <div style={{ fontSize: 'var(--fs-sm)', color: 'var(--faint)', margin: '2px 0 12px' }}>{preview.folder ? preview.folder + '/' : '(root)'} · {preview.width && preview.height ? `${preview.width}×${preview.height}` : 'unknown size'} · {human(preview.size_bytes)} · {preview.content_type}</div>
              <div className="field"><label>Usage type</label>
                <select className="inp" value={preview.kind} onChange={e => changeKind(preview, e.target.value)}>
                  {ASSIGNABLE.map(k => <option key={k} value={k}>{k}</option>)}
                </select>
                <div className="hintxt">Controls where it appears in pickers (slate / watermark / brand / poster). Change any time.</div>
              </div>
              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10, marginTop: 8 }}>
                <button className="btn primary" onClick={() => { setBuilder(preview); setPreview(null) }}>URL builder…</button>
                <button className="btn ghost" onClick={() => setPreview(null)}>Close</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {builder && <UrlBuilder file={builder} onClose={() => setBuilder(null)} notify={m => { setToast(m); setTimeout(() => setToast(''), 2200) }} />}

      {toast && (
        <div style={{ position: 'fixed', left: '50%', bottom: 26, transform: 'translateX(-50%)', zIndex: 60, background: 'var(--panel-3)', border: '1px solid var(--border-2)', color: 'var(--text)', padding: '10px 16px', borderRadius: 10, fontSize: 'var(--fs-body)', boxShadow: 'var(--shadow)' }}>{toast}</div>
      )}

      {folderModal !== null && (
        <div className="drawer-scrim" {...pressable((e: any) => { ((() => setFolderModal(null)) as any)(e) })} data-a11y-click="" style={{ alignItems: 'center', justifyContent: 'center' }}>
          <form className="card" onClick={e => e.stopPropagation()} style={{ width: 420, padding: 20 }}
            onSubmit={e => { e.preventDefault(); createFolder(folderModal) }}>
            <h3 style={{ margin: '0 0 4px' }}>New folder</h3>
            <p style={{ color: 'var(--muted)', fontSize: 'var(--fs-sm)', margin: '0 0 12px' }}>Use “/” for nested folders, e.g. <span style={{ fontFamily: 'ui-monospace,monospace' }}>slates/news</span>.</p>
            <input className="inp" autoFocus value={folderModal} onChange={e => setFolderModal(e.target.value)} placeholder="slates/news" />
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10, marginTop: 16 }}>
              <button type="button" className="btn ghost" onClick={() => setFolderModal(null)}>Cancel</button>
              <button type="submit" className="btn primary" disabled={!folderModal.trim()}>Create folder</button>
            </div>
          </form>
        </div>
      )}

      {confirm && (
        <div className="drawer-scrim" {...pressable((e: any) => { ((() => setConfirm(null)) as any)(e) })} data-a11y-click="" style={{ alignItems: 'center', justifyContent: 'center' }}>
          <div className="card" {...pressable((e: any) => { (((e: any) => e.stopPropagation()) as any)(e) })} data-a11y-click="" style={{ width: 420, padding: 20 }}>
            <h3 style={{ margin: '0 0 8px' }}>Delete image?</h3>
            <p style={{ color: 'var(--muted)', fontSize: 'var(--fs-body)' }}><b>{confirm.file.path}</b> — this can’t be undone.</p>
            {confirm.inUse && confirm.inUse.length > 0 && (
              <div className="err" style={{ marginBottom: 8 }}>In use as a slate by {confirm.inUse.length} channel(s): {confirm.inUse.map((c: any) => c.name).join(', ')}. Force-delete anyway?</div>
            )}
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10, marginTop: 14 }}>
              <button className="btn ghost" onClick={() => setConfirm(null)}>Cancel</button>
              <button className="btn primary" style={{ background: 'var(--down)' }} onClick={() => doDelete(confirm.file, !!(confirm.inUse && confirm.inUse.length))}>
                {confirm.inUse && confirm.inUse.length ? 'Force delete' : 'Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

function FolderRow({ label, active, onClick, count, depth }: { label: string; active: boolean; onClick: () => void; count: number; depth: number }) {
  return (
    <div {...pressable((e: any) => { ((onClick) as any)(e) })} data-a11y-click="" className={`nav-item ${active ? 'active' : ''}`}
      style={{ paddingLeft: 8 + depth * 12, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 8, borderRadius: 8 }}>
      <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" /></svg>
      <span style={{ flex: 1, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{label}</span>
      <span style={{ fontSize: 'var(--fs-label)', color: 'var(--faint)' }}>{count}</span>
    </div>
  )
}

/* ------------------------------------------------------------- URL builder */
/** Compose a derivative URL for an image in ONE preview window.
 *
 *  The preview shows the source with the filters approximated live (CSS), and
 *  everything is set by interacting directly ON it:
 *    - focal point: a draggable CROSSHAIR; cover resizes keep it in frame
 *    - crop: drag a rectangle in Crop mode (outside dimmed)
 *    - the bright outline is the OUTPUT FRAME: exactly what a cover resize at
 *      the current size will keep, so the result is visible without a second
 *      pane. The URL below is copy-ready. */
function UrlBuilder({ file, onClose, notify }: { file: MediaFile; onClose: () => void; notify: (m: string) => void }) {
  const srcW = file.width || 1280, srcH = file.height || 720
  const [w, setW] = useState(String(Math.min(640, srcW)))
  const [h, setH] = useState(String(Math.max(1, Math.round(Math.min(640, srcW) * (srcH / srcW)))))
  const [fit, setFit] = useState<'cover' | 'inside' | 'contain' | 'fill'>('cover')
  const [mode, setMode] = useState<'focus' | 'crop'>('focus')
  const [focus, setFocus] = useState<{ x: number; y: number } | null>(null)
  const [crop, setCrop] = useState<{ x: number; y: number; w: number; h: number } | null>(null)
  const [gray, setGray] = useState(false)
  const [blur, setBlur] = useState(0)
  const [bright, setBright] = useState(100)
  const [sat, setSat] = useState(100)
  const [sharpen, setSharpen] = useState(false)
  const [q, setQ] = useState(80)
  const [fmt, setFmt] = useState<'webp' | 'jpeg' | 'png'>('webp')
  const drag = useRef<{ kind: 'focus' | 'crop'; ax: number; ay: number } | null>(null)
  const box = useRef<HTMLDivElement | null>(null)

  const key = file.url.replace(/^\//, '')      // library/<acct>/<path>
  const spec = (() => {
    const t: string[] = [`${Math.max(1, +w || 1)}x${Math.max(1, +h || 1)}`, fit]
    if (crop) t.push(`crop=${Math.round(crop.x)}-${Math.round(crop.y)}-${Math.round(crop.w)}-${Math.round(crop.h)}`)
    if (fit === 'cover' && focus) t.push(`focus=${Math.round(focus.x)}-${Math.round(focus.y)}`)
    if (gray) t.push('gray')
    if (blur > 0) t.push(`blur=${blur}`)
    if (bright !== 100) t.push(`bright=${bright}`)
    if (sat !== 100) t.push(`sat=${sat}`)
    if (sharpen) t.push('sharp')
    if (q !== 80) t.push(`q=${q}`)
    if (fmt !== 'webp') t.push(`fmt=${fmt}`)
    return t.join(',')
  })()
  const path = `/img/${spec}/${key}`
  const absolute = `${window.location.origin}${path}`

  /** The OUTPUT FRAME in source-percent coords: what a cover resize keeps.
   *  Mirrors the server maths (crop first, focal window inside it). */
  const kept = (() => {
    if (fit !== 'cover') return crop     // non-cover: the crop is the frame
    const W = Math.max(1, +w || 1), H = Math.max(1, +h || 1)
    const rg = crop ?? { x: 0, y: 0, w: 100, h: 100 }
    const rw = (rg.w / 100) * srcW, rh = (rg.h / 100) * srcH
    const scale = Math.max(W / rw, H / rh)
    const kw = Math.min(rw, W / scale), kh = Math.min(rh, H / scale)
    const fx = focus ? Math.max(rg.x, Math.min(rg.x + rg.w, focus.x)) : rg.x + rg.w / 2
    const fy = focus ? Math.max(rg.y, Math.min(rg.y + rg.h, focus.y)) : rg.y + rg.h / 2
    const kwP = (kw / srcW) * 100, khP = (kh / srcH) * 100
    const x = Math.max(rg.x, Math.min(rg.x + rg.w - kwP, fx - kwP / 2))
    const y = Math.max(rg.y, Math.min(rg.y + rg.h - khP, fy - khP / 2))
    return { x, y, w: kwP, h: khP }
  })()

  // ---- pointer interactions on the ONE preview ------------------------------
  const pct = (e: { clientX: number; clientY: number }) => {
    const r = box.current!.getBoundingClientRect()
    return {
      x: Math.max(0, Math.min(100, ((e.clientX - r.left) / r.width) * 100)),
      y: Math.max(0, Math.min(100, ((e.clientY - r.top) / r.height) * 100)),
    }
  }
  function down(e: React.PointerEvent) {
    e.preventDefault(); (e.target as Element).setPointerCapture?.(e.pointerId)
    const p = pct(e)
    if (mode === 'focus') {
      drag.current = { kind: 'focus', ax: p.x, ay: p.y }
      setFocus(p)
      if (fit !== 'cover') setFit('cover')
    } else {
      drag.current = { kind: 'crop', ax: p.x, ay: p.y }
      setCrop({ x: p.x, y: p.y, w: 0, h: 0 })
    }
  }
  function move(e: React.PointerEvent) {
    if (!drag.current) return
    const p = pct(e)
    if (drag.current.kind === 'focus') setFocus(p)
    else {
      const { ax, ay } = drag.current
      setCrop({ x: Math.min(ax, p.x), y: Math.min(ay, p.y), w: Math.abs(p.x - ax), h: Math.abs(p.y - ay) })
    }
  }
  function up() {
    if (drag.current?.kind === 'crop') {
      setCrop(c => (c && (c.w < 2 || c.h < 2)) ? null : c)   // sub-2% drag = click
      setMode('focus')
    }
    drag.current = null
  }

  async function copy() {
    try { await navigator.clipboard.writeText(absolute); notify('URL copied') }
    catch {
      const el = document.createElement('textarea')
      el.value = absolute; document.body.appendChild(el); el.select()
      document.execCommand('copy'); document.body.removeChild(el)
      notify('URL copied')
    }
  }

  const cssFilter = [
    gray ? 'grayscale(1)' : '',
    blur > 0 ? `blur(${(blur / 5).toFixed(1)}px)` : '',
    bright !== 100 ? `brightness(${bright / 100})` : '',
    sat !== 100 ? `saturate(${sat / 100})` : '',
  ].filter(Boolean).join(' ')

  const Slider = ({ label, value, set, min, max, step = 1, suffix = '' }: {
    label: string; value: number; set: (v: number) => void; min: number; max: number; step?: number; suffix?: string
  }) => (
    <div className="field" style={{ margin: 0 }}>
      <label>{label} — {value}{suffix}</label>
      <input type="range" min={min} max={max} step={step} value={value}
        onChange={e => set(Number(e.target.value))} style={{ width: '100%', accentColor: 'var(--brand)' }} />
    </div>
  )

  return (
    <div className="drawer-scrim" {...pressable((e: any) => { ((onClose) as any)(e) })} data-a11y-click="" style={{ alignItems: 'center', justifyContent: 'center' }}>
      <div className="card" {...pressable((e: any) => { (((e: any) => e.stopPropagation()) as any)(e) })} data-a11y-click="" style={{ width: 1040, maxWidth: '96vw', maxHeight: '92vh', overflowY: 'auto', padding: 0 }}>
        <div className="drawer-h"><div className="t">Image URL builder — {file.name}</div><button className="xbtn" onClick={onClose}>✕</button></div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 300px', gap: 18, padding: 18 }}>
          <div>
            {/* -------- the ONE preview: filters live, focus + crop overlaid -------- */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
              <button className={`btn ${mode === 'focus' ? 'primary' : 'ghost'}`} style={{ padding: '4px 10px', fontSize: 'var(--fs-sm)' }} onClick={() => setMode('focus')}>Focus point</button>
              <button className={`btn ${mode === 'crop' ? 'primary' : 'ghost'}`} style={{ padding: '4px 10px', fontSize: 'var(--fs-sm)' }} onClick={() => setMode('crop')}>Crop</button>
              {focus && <button className="btn ghost" style={{ padding: '4px 10px', fontSize: 'var(--fs-sm)' }} onClick={() => setFocus(null)}>clear focus</button>}
              {crop && <button className="btn ghost" style={{ padding: '4px 10px', fontSize: 'var(--fs-sm)' }} onClick={() => setCrop(null)}>clear crop</button>}
              <span style={{ fontSize: 'var(--fs-label)', color: 'var(--faint)', marginLeft: 'auto' }}>{srcW}×{srcH}</span>
            </div>
            <div style={{ display: 'grid', placeItems: 'center', background: 'repeating-conic-gradient(#1a1f2b 0% 25%, #141821 0% 50%) 50% / 18px 18px', borderRadius: 10, padding: 8 }}>
              <div ref={box} className="src-view" onPointerDown={down} onPointerMove={move} onPointerUp={up}
                style={{ position: 'relative', display: 'inline-block', cursor: mode === 'crop' ? 'crosshair' : 'default', touchAction: 'none', userSelect: 'none', lineHeight: 0 }}>
                <img src={thumbUrl(file.url, 900, 520, 'inside')} alt="" draggable={false}
                  style={{ maxWidth: '100%', maxHeight: 380, display: 'block', pointerEvents: 'none', filter: cssFilter || undefined }} />
                {/* crop: dim everything outside */}
                {crop && crop.w > 0 && (
                  <>
                    <div style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,.55)', pointerEvents: 'none',
                      clipPath: `polygon(0 0, 100% 0, 100% 100%, 0 100%, 0 ${crop.y}%, ${crop.x}% ${crop.y}%, ${crop.x}% ${crop.y + crop.h}%, ${crop.x + crop.w}% ${crop.y + crop.h}%, ${crop.x + crop.w}% ${crop.y}%, 0 ${crop.y}%)` }} />
                    <div style={{ position: 'absolute', left: `${crop.x}%`, top: `${crop.y}%`, width: `${crop.w}%`, height: `${crop.h}%`, border: '1.5px dashed rgba(255,255,255,.85)', pointerEvents: 'none' }} />
                  </>
                )}
                {/* the output frame a cover resize keeps */}
                {kept && fit === 'cover' && (
                  <div style={{ position: 'absolute', left: `${kept.x}%`, top: `${kept.y}%`, width: `${kept.w}%`, height: `${kept.h}%`,
                    border: '2px solid var(--brand,#5b8cff)', borderRadius: 3, boxShadow: '0 0 0 1px rgba(0,0,0,.6), inset 0 0 0 1px rgba(0,0,0,.35)', pointerEvents: 'none' }} />
                )}
                {/* focal CROSSHAIR */}
                {focus && (
                  <div style={{ position: 'absolute', left: `${focus.x}%`, top: `${focus.y}%`, width: 0, height: 0, pointerEvents: 'none' }}>
                    <div style={{ position: 'absolute', left: -14, top: -1, width: 28, height: 2, background: '#fff', boxShadow: '0 0 3px rgba(0,0,0,.9)' }} />
                    <div style={{ position: 'absolute', left: -1, top: -14, width: 2, height: 28, background: '#fff', boxShadow: '0 0 3px rgba(0,0,0,.9)' }} />
                  </div>
                )}
              </div>
            </div>
            <div className="hintxt" style={{ marginTop: 6 }}>
              <b>Drag</b> to {mode === 'focus' ? 'place the focus crosshair' : 'draw the crop rectangle'}.
              {fit === 'cover' ? ' The blue outline is the output frame: exactly what your size keeps.' : ''}
              {crop ? ` Crop ${Math.round(crop.w)}×${Math.round(crop.h)}% at ${Math.round(crop.x)},${Math.round(crop.y)}.` : ''}
            </div>
            <div className="field" style={{ marginTop: 10 }}>
              <label>URL — paste anywhere; resized and cached on first request</label>
              <div style={{ display: 'flex', gap: 8 }}>
                <input className="inp url-out" readOnly value={absolute} onFocus={e => e.currentTarget.select()} style={{ flex: 1, fontFamily: 'ui-monospace,monospace', fontSize: 'var(--fs-sm)' }} />
                <button className="btn ghost" onClick={() => window.open(absolute, '_blank')} title="Open the rendered output in a new tab">View</button>
                <button className="btn primary" onClick={copy}>Copy</button>
              </div>
            </div>
          </div>
          {/* -------- controls -------- */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
              <div className="field" style={{ margin: 0 }}><label>Width</label>
                <input className="inp" inputMode="numeric" value={w} onChange={e => setW(e.target.value.replace(/[^0-9]/g, ''))} />
              </div>
              <div className="field" style={{ margin: 0 }}><label>Height</label>
                <input className="inp" inputMode="numeric" value={h} onChange={e => setH(e.target.value.replace(/[^0-9]/g, ''))} />
              </div>
            </div>
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
              {([['16:9', 16 / 9], ['4:3', 4 / 3], ['1:1', 1], ['9:16', 9 / 16]] as const).map(([lbl, r]) => (
                <button key={lbl} className="btn ghost" style={{ padding: '4px 10px', fontSize: 'var(--fs-sm)' }}
                  onClick={() => setH(String(Math.max(1, Math.round((+w || 640) / r))))}>{lbl}</button>
              ))}
            </div>
            <div className="field" style={{ margin: 0 }}><label>Fit</label>
              <select className="inp" value={fit} onChange={e => setFit(e.target.value as any)}>
                <option value="cover">Cover — fill the box, crop overflow</option>
                <option value="inside">Inside — fit within, keep aspect</option>
                <option value="contain">Contain — fit within, pad to box</option>
                <option value="fill">Fill — stretch to box</option>
              </select>
            </div>
            <div style={{ fontSize: 'var(--fs-label)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.06em', color: 'var(--faint)', marginTop: 4 }}>Filters</div>
            <Slider label="Brightness" value={bright} set={setBright} min={10} max={300} suffix="%" />
            <Slider label="Saturation" value={sat} set={setSat} min={0} max={300} suffix="%" />
            <Slider label="Blur" value={blur} set={setBlur} min={0} max={30} />
            <div style={{ display: 'flex', gap: 14 }}>
              <label style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 'var(--fs-body)', cursor: 'pointer' }}>
                <input type="checkbox" checked={gray} onChange={e => setGray(e.target.checked)} /> Grayscale
              </label>
              <label style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 'var(--fs-body)', cursor: 'pointer' }}>
                <input type="checkbox" checked={sharpen} onChange={e => setSharpen(e.target.checked)} /> Sharpen
              </label>
            </div>
            <div style={{ fontSize: 'var(--fs-label)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.06em', color: 'var(--faint)', marginTop: 4 }}>Output</div>
            <Slider label="Quality" value={q} set={setQ} min={30} max={100} />
            <div className="field" style={{ margin: 0 }}><label>Format</label>
              <select className="inp" value={fmt} onChange={e => setFmt(e.target.value as any)}>
                <option value="webp">WebP (smallest, recommended)</option>
                <option value="jpeg">JPEG</option>
                <option value="png">PNG (lossless)</option>
              </select>
            </div>
            <button className="btn ghost" style={{ marginTop: 4 }} onClick={() => {
              setFit('cover'); setMode('focus'); setFocus(null); setCrop(null); setGray(false); setBlur(0); setBright(100); setSat(100); setSharpen(false); setQ(80); setFmt('webp')
              setW(String(Math.min(640, srcW))); setH(String(Math.max(1, Math.round(Math.min(640, srcW) * (srcH / srcW)))))
            }}>Reset</button>
          </div>
        </div>
      </div>
    </div>
  )
}
