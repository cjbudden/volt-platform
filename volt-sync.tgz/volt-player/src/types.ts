// ============================================================================
//  The contract between the embed, the control plane and a layout.
//
//  Kept in its own file because a layout author is expected to read this and
//  nothing else: a skin needs to know what it will be handed and what it may
//  call, and should not have to read the Shaka wiring to find out.
// ============================================================================

export interface VoltPlayerOptions {
  /** Where to render. A CSS selector or the element itself. */
  el: string | HTMLElement;
  /** The publishable key (pk_…) of the app this player belongs to. */
  appKey: string;
  /** The station. */
  channelId: string;
  /**
   * The control plane's origin. Defaults to the origin the script itself was
   * served from, which is right for every ordinary embed and wrong only when
   * somebody self-hosts the bundle on their own CDN — hence the override.
   */
  apiBase?: string;
  /** Override the saved configuration, for previewing a skin before saving. */
  config?: Partial<PlayerConfig>;
  /**
   * Delivery preference. `auto` picks MP3 first, which is deliberate: it needs
   * no Media Source Extensions, starts faster, and is what a radio embed
   * actually wants. HLS and DASH are there for a browser or network where MP3
   * streaming is blocked.
   */
  preferred?: 'auto' | 'mp3' | 'hls' | 'dash';
  /** Start playing without a click. Usually blocked by the browser; see core. */
  autoplay?: boolean;
  /** Called for every reportable event, before it is batched and sent. */
  onEvent?: (e: PlayerEvent) => void;
}

export interface PlayerConfig {
  layout: 'card' | 'bar' | 'hero';
  primaryColor: string;
  secondaryColor: string;
  options: Record<string, unknown>;
  fallbackTitle: string | null;
  fallbackText: string | null;
  fallbackArtworkUrl: string | null;
}

export interface SessionResponse {
  station: { id: string; name: string; description: string | null; artworkUrl: string | null; onAir: boolean };
  sources: { mp3: string | null; hls: string; dash: string };
  config: PlayerConfig;
  report: { url: string; ttlSec: number };
}

/** What the layout renders. Already resolved server-side, fallback applied. */
export interface NowPlaying {
  primary: string;
  secondary: string | null;
  artworkUrl: string | null;
  source: 'track' | 'station';
  album: string | null;
  year: number | null;
  onAir: boolean;
  raw: string | null;
  since: number | null;
}

export type PlayerEventName =
  | 'player.load' | 'player.ready'
  | 'manifest.ok' | 'manifest.error'
  | 'play' | 'pause' | 'stop'
  | 'stall' | 'recover'
  | 'error';

export interface PlayerEvent {
  event: PlayerEventName;
  at: number;
  layout?: string;
  detail?: Record<string, unknown>;
}

/**
 * What a layout is given.
 *
 * A layout receives DATA and COMMANDS and nothing else — no Shaka instance, no
 * media element, no fetch. That is what makes a third-party skin safe to
 * accept: it cannot reach past its own box into the transport, so a bad skin
 * renders badly instead of breaking playback or leaking the session.
 */
export interface LayoutContext {
  root: HTMLElement;
  config: PlayerConfig;
  station: SessionResponse['station'];
  /** Commands. */
  play(): void;
  pause(): void;
  toggle(): void;
  setVolume(v: number): void;
  getVolume(): number;
}

export interface LayoutState {
  playing: boolean;
  loading: boolean;
  /** Present only when something has gone wrong, already made readable. */
  error: string | null;
  nowPlaying: NowPlaying | null;
}

export interface Layout {
  /** Build the DOM once. */
  mount(ctx: LayoutContext): void;
  /** Called on every state change. Must be cheap and idempotent. */
  update(state: LayoutState): void;
  destroy?(): void;
}
