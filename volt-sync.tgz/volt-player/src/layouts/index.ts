// ============================================================================
//  Layout registry.
//
//  A named lookup with a FALLBACK rather than a map access, because the layout
//  name arrives from the database and from an embedder's options object. A
//  config saved by a newer console, or a typo in an embed, must render the
//  default player rather than throwing and leaving a blank box on a customer's
//  website.
//
//  `bar` and `hero` are declared in the API's layout list and are the next two
//  to be written; they fall through to the card until they exist, which is a
//  visibly wrong skin rather than a broken embed.
// ============================================================================
import type { Layout } from '../types'
import { cardLayout } from './card'

const REGISTRY: Record<string, () => Layout> = {
  card: cardLayout,
}

export function pickLayout(name: string | undefined): Layout {
  const make = REGISTRY[String(name ?? 'card')] ?? cardLayout
  return make()
}

export function layoutNames(): string[] { return Object.keys(REGISTRY) }
