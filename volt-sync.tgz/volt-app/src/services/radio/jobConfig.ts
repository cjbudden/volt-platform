// ============================================================================
//  RADIO JOB CONFIG — what a station container is told.
//
//  The counterpart of buildEncoderJobConfig, and deliberately the same shape of
//  thing: everything the task needs, handed over as JSON at launch, so the
//  container needs no database, no credentials of its own and no discovery. It
//  is given a source to read, somewhere to put the output, a relay to push MP3
//  to, and an address to report status back to. Nothing else.
//
//  The keys are snake_case because this crosses into Python. That is the only
//  reason, and it is worth the small ugliness: the boundary is a wire format,
//  and pretending otherwise is how a rename in TypeScript silently stops a
//  station in production.
// ============================================================================
import { config } from '../../config';
import { clampBitrate, resolveOutputs, type RadioOutputs } from './args';

export interface RadioJobCtx {
  channelId: string;
  channelName?: string | null;
  protocol: string;
  url: string;
  radioConfig: {
    outputs?: RadioOutputs;
    bitrateKbps?: number;
    transcode?: boolean;
  } | null | undefined;
}

/**
 * The mount a station publishes on.
 *
 * Derived from the channel id rather than its name on purpose: a name can be
 * edited, and a listener URL that changes when somebody fixes a typo is a
 * broken URL. Hardware receivers in particular are configured once and never
 * again.
 */
export function mountFor(channelId: string): string {
  return `${channelId}.mp3`;
}

/**
 * The URL a LISTENER is given. This is the relay's public face, which is
 * normally a CDN or load balancer, and is never the in-VPC host:port the
 * station uses to reach Icecast. Falling back to host:port is a development
 * convenience and would be wrong to serve in production, which is why
 * ICECAST_PUBLIC_BASE exists and why this is the only place that decides it.
 */
export function publicMp3Url(channelId: string): string {
  const ice = config.icecast;
  const base = ice.publicBase
    || `${ice.tls ? 'https' : 'http'}://${ice.host}:${ice.port}`;
  return `${base.replace(/\/+$/, '')}/${mountFor(channelId)}`;
}

export function buildRadioJobConfig(ctx: RadioJobCtx): Record<string, any> {
  const rc = ctx.radioConfig ?? {};
  const outs = resolveOutputs(rc.outputs);
  const ice = config.icecast;

  return {
    channel_id: ctx.channelId,
    protocol: ctx.protocol,
    url: ctx.url,
    outputs: outs,
    bitrate_kbps: clampBitrate(rc.bitrateKbps),
    transcode: !!rc.transcode,
    segment_seconds: 4,

    // The source codec is deliberately NOT probed here. The container is the
    // party that can actually reach the source; on ECS the control plane
    // usually cannot, and a probe that fails from here would silently force a
    // re-encode on a station that could have been copied.
    // radio.py probes when this key is absent.

    icecast: outs.mp3 ? {
      host: ice.host,
      port: ice.port,
      mount: mountFor(ctx.channelId),
      username: ice.sourceUser,
      password: ice.sourcePassword,
      station_name: ctx.channelName ?? null,
      tls: ice.tls,
    } : null,

    s3: {
      bucket: config.aws.s3Bucket,
      prefix: `channel/${ctx.channelId}`,
    },
    status_report: {
      url: `${config.internalApiBaseUrl}/api/streams/${ctx.channelId}/report`,
      token: config.ingestToken,
    },
  };
}
