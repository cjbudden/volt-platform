import { config } from '../../config';
import { Orchestrator } from './service';
import { reconcileFleet } from '../fleet/reconcile';
import { meterOnce } from '../fleet/meter';
import { sampleFleet, pruneSamples } from '../fleet/metrics';

export { Orchestrator } from './service';
export * from './launcher';

/** Shared orchestrator instance used by routes and the scheduler. */
export const orchestrator = new Orchestrator();

/**
 * Start the background scheduler: provision/stop scheduled events, roll channel
 * recordings at the day boundary, and sweep expired recordings. Returns a stop
 * fn. In production the event-scheduling half can be moved to EventBridge; the
 * retention sweep can move to a scheduled Lambda. The logic in service.ts is
 * unchanged either way.
 */
export function startScheduler(): () => void {
  const o = config.orchestrator;
  // FIRST, before any tick: the stored 'live' flags are a cache of a running
  // process, and a crash leaves them stale. Reconcile them against what is
  // actually running so nothing downstream reports a status that is not true.
  orchestrator.reconcileStreamStatus()
    .then((n) => { if (n) console.log(`[orchestrator] boot reconcile corrected ${n} stream status row(s)`); })
    .catch((e) => console.error('[orchestrator] boot reconcile failed', e));
  const tick = setInterval(
    () => orchestrator.tick().catch((e) => console.error('[orchestrator] tick error', e)),
    o.tickSeconds * 1000
  );
  const sweep = setInterval(
    () => orchestrator.sweepRetention().catch((e) => console.error('[orchestrator] sweep error', e)),
    o.retentionSweepSeconds * 1000
  );

  // THE FLEET PASS, kept on its own interval and its own error boundary.
  //
  // It observes and meters; it can start nothing and stop nothing. Keeping it
  // out of orchestrator.tick() means a throttled AWS describe or a slow meter
  // batch can never delay or fail the pass that actually keeps channels on
  // air. The reverse is also true and also wanted: a stream that fails to
  // start does not cost us the usage record for the forty that are running.
  const fleet = setInterval(
    () => fleetPass().catch((e) => console.error('[fleet] pass error', e)),
    o.fleetTickSeconds * 1000
  );
  // Prune telemetry on the same schedule as retention; the ledger is never
  // pruned, because it is the billable record.
  const prune = setInterval(
    () => pruneSamples(o.sampleRetentionDays).catch((e) => console.error('[fleet] prune error', e)),
    o.retentionSweepSeconds * 1000
  );

  tick.unref?.();
  sweep.unref?.();
  fleet.unref?.();
  prune.unref?.();
  console.log(`[orchestrator] scheduler up (tick ${o.tickSeconds}s, retention sweep ${o.retentionSweepSeconds}s, fleet ${o.fleetTickSeconds}s, launcher=${o.launcher})`);
  return () => {
    clearInterval(tick);
    clearInterval(sweep);
    clearInterval(fleet);
    clearInterval(prune);
  };
}

/**
 * One fleet pass: observe placement, then meter, then measure.
 *
 * THE ORDER IS LOAD-BEARING. Placement first, because the meter reads the
 * host's instance type to price the window and a task with no host yet is
 * metered unpriced. Metering second, so the seconds are captured even if the
 * metrics provider is unreachable. Measurement last, because it is the only
 * part nobody is billed for.
 *
 * Each stage has its own try/catch for the same reason they are in this order:
 * a failure in a later, less important stage must not discard the work of an
 * earlier, more important one.
 */
export async function fleetPass(): Promise<void> {
  try {
    await reconcileFleet(orchestrator.launcherForFleet());
  } catch (e) { console.error('[fleet] placement reconcile failed', e); }
  try {
    const m = await meterOnce();
    if (m.windows) console.log(`[fleet] metered ${m.windows} window(s), ${m.seconds}s across ${m.considered} task(s)`);
  } catch (e) { console.error('[fleet] meter failed', e); }
  try {
    await sampleFleet();
  } catch (e) { console.error('[fleet] telemetry sample failed', e); }
}
